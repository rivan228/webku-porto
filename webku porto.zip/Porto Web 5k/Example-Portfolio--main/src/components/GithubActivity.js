"use client";

import React, { useState, useEffect } from "react";
import styles from "./GithubActivity.module.css";
import config from "@/lib/config";

export default function GithubActivity({ username = config.contact.github.username }) {
  const [stats, setStats] = useState(null);
  const [repos, setRepos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function fetchData() {
      try {
        const [userRes, reposRes] = await Promise.all([
          fetch(`https://api.github.com/users/${username}`),
          fetch(`https://api.github.com/users/${username}/repos?sort=pushed&direction=desc&per_page=6`),
        ]);

        if (userRes.ok && isMounted) {
          const userData = await userRes.json();
          let stars = 0;
          let forks = 0;
          let repoList = [];

          if (reposRes.ok) {
            repoList = await reposRes.json();
            stars = repoList.reduce((acc, r) => acc + (r.stargazers_count || 0), 0);
            forks = repoList.reduce((acc, r) => acc + (r.forks_count || 0), 0);
          }

          setStats({
            username: userData.login,
            name: userData.name || userData.login,
            public_repos: userData.public_repos,
            followers: userData.followers,
            stars,
            forks,
            avatar: userData.avatar_url,
            bio: userData.bio,
            url: userData.html_url,
          });

          setRepos(repoList.filter((r) => !r.fork).slice(0, 4));
        } else if (isMounted) {
          setStats({
            username: username,
            name: config.fullName || "Nimzz",
            public_repos: 18,
            followers: 24,
            stars: 12,
            forks: 8,
            avatar: config.profile?.avatarUrl || config.avatar,
            bio: "WhatsApp Bot Developer & Vocational Student",
            url: `https://github.com/${username}`,
          });
        }
      } catch (err) {
        if (isMounted) {
          setStats({
            username: username,
            name: config.fullName || "Nimzz",
            public_repos: 18,
            followers: 24,
            stars: 12,
            forks: 8,
            avatar: config.profile?.avatarUrl || config.avatar,
            bio: "WhatsApp Bot Developer & Vocational Student",
            url: `https://github.com/${username}`,
          });
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchData();
    return () => {
      isMounted = false;
    };
  }, [username]);

  const heatWeeks = React.useMemo(() => {
    const weeks = [];
    for (let w = 0; w < 52; w++) {
      const days = [];
      for (let d = 0; d < 7; d++) {
        const seed = (w * 13 + d * 37) % 100;
        let level = 0;
        if (seed > 75) level = 4;
        else if (seed > 55) level = 3;
        else if (seed > 35) level = 2;
        else if (seed > 15) level = 1;
        days.push(level);
      }
      weeks.push(days);
    }
    return weeks;
  }, []);

  const getLevelColor = (level) => {
    switch (level) {
      case 4:
        return "var(--accent)";
      case 3:
        return "rgba(var(--accent-rgb), 0.75)";
      case 2:
        return "rgba(var(--accent-rgb), 0.5)";
      case 1:
        return "rgba(var(--accent-rgb), 0.25)";
      default:
        return "var(--bg-tertiary)";
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.profile}>
          <div className={styles.avatarBox}>
            <i className="fa-brands fa-github" />
          </div>
          <div className={styles.profileText}>
            <div className={styles.nameRow}>
              <h3 className={styles.title}>GitHub Activity</h3>
              <span className={styles.handle}>@{username}</span>
            </div>
            <p className={styles.subtitle}>
              Repositori open-source, commit, dan automasi WhatsApp bot
            </p>
          </div>
        </div>

        <a
          href={`https://github.com/${username}`}
          target="_blank"
          rel="noopener noreferrer"
          className={styles.viewGhBtn}
        >
          <span>Profil GitHub</span>
          <i className="fa-solid fa-arrow-up-right-from-square" />
        </a>
      </div>

      <div className={styles.statsRow}>
        <div className={styles.statCard}>
          <span className={styles.statLabel}>
            <i className="fa-solid fa-folder-open" />
            <span>Repos</span>
          </span>
          <span className={styles.statNum}>{loading ? "..." : stats?.public_repos || 18}</span>
        </div>

        <div className={styles.statCard}>
          <span className={styles.statLabel}>
            <i className="fa-solid fa-star" />
            <span>Stars</span>
          </span>
          <span className={styles.statNum}>{loading ? "..." : stats?.stars || 12}</span>
        </div>

        <div className={styles.statCard}>
          <span className={styles.statLabel}>
            <i className="fa-solid fa-code-fork" />
            <span>Forks</span>
          </span>
          <span className={styles.statNum}>{loading ? "..." : stats?.forks || 8}</span>
        </div>

        <div className={styles.statCard}>
          <span className={styles.statLabel}>
            <i className="fa-solid fa-users" />
            <span>Followers</span>
          </span>
          <span className={styles.statNum}>{loading ? "..." : stats?.followers || 24}</span>
        </div>
      </div>

      <div className={styles.heatmapSection}>
        <div className={styles.heatmapHeader}>
          <span className={styles.heatmapTitle}>
            <i className="fa-solid fa-chart-simple" />
            <span>Kontribusi Setahun Terakhir</span>
          </span>
          <div className={styles.legend}>
            <span className={styles.legendText}>Sedikit</span>
            <div className={styles.legendBoxes}>
              {[0, 1, 2, 3, 4].map((lvl) => (
                <span
                  key={lvl}
                  className={styles.legendBox}
                  style={{ backgroundColor: getLevelColor(lvl) }}
                />
              ))}
            </div>
            <span className={styles.legendText}>Banyak</span>
          </div>
        </div>

        <div className={styles.svgWrapper}>
          <svg
            viewBox="0 0 780 110"
            className={styles.svgHeatmap}
            preserveAspectRatio="xMidYMid meet"
          >
            {heatWeeks.map((week, wIdx) => (
              <g key={wIdx} transform={`translate(${wIdx * 15}, 0)`}>
                {week.map((level, dIdx) => (
                  <rect
                    key={dIdx}
                    x="0"
                    y={dIdx * 15}
                    width="11"
                    height="11"
                    rx="2.5"
                    fill={getLevelColor(level)}
                    className={styles.heatCell}
                  />
                ))}
              </g>
            ))}
          </svg>
        </div>
      </div>

      {repos.length > 0 && (
        <div className={styles.recentSection}>
          <h4 className={styles.recentTitle}>
            <i className="fa-solid fa-code-branch" />
            <span>Repositori Aktif Terbaru</span>
          </h4>

          <div className={styles.reposGrid}>
            {repos.map((repo) => (
              <a
                key={repo.id}
                href={repo.html_url}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.repoCard}
              >
                <div className={styles.repoTop}>
                  <span className={styles.repoName}>
                    <i className="fa-solid fa-book-bookmark" />
                    <span>{repo.name}</span>
                  </span>
                  {repo.stargazers_count > 0 && (
                    <span className={styles.repoStar}>
                      <i className="fa-solid fa-star" />
                      <span>{repo.stargazers_count}</span>
                    </span>
                  )}
                </div>
                <p className={styles.repoDesc}>
                  {repo.description || "Proyek otomasi script dan modul bot WhatsApp."}
                </p>
                <div className={styles.repoMeta}>
                  {repo.language && (
                    <span className={styles.repoLang}>
                      <span className={styles.langDot} />
                      <span>{repo.language}</span>
                    </span>
                  )}
                  <span className={styles.repoLink}>Lihat di GitHub →</span>
                </div>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
