"use client";

import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkBreaks from "remark-breaks";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import styles from "./AIAssistant.module.css";
import config from "@/lib/config";

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [showNudge, setShowNudge] = useState(false);
  const [githubStats, setGithubStats] = useState(null);
  const [projects, setProjects] = useState([]);
  const initialMessage = {
    role: "assistant",
    content:
      "Haaai, makasih ya udah mampir ngobrol sama aku! Aku Aiko, AI-nya Rivan, dan aku seneng banget bisa bantu kamu. Yuk tanya-tanya soal:\n\n- Project & bot WhatsApp yang pernah dibuat\n- Skill sama bahasa pemrograman yang dipakai\n- Cara hubungin Rivan\n\nMau nanya apa nih? Aku siap dengerin~",
    timestamp: new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    }),
  };

  const [messages, setMessages] = useState([initialMessage]);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [vpHeight, setVpHeight] = useState("100dvh");
  const isOpenRef = useRef(isOpen);

  useEffect(() => {
    isOpenRef.current = isOpen;
  }, [isOpen]);

  useEffect(() => {
    const saved = localStorage.getItem("nimzz_chat_history");
    if (saved) {
      try {
        setMessages(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse chat history");
      }
    }
  }, []);

  useEffect(() => {
    if (messages.length > 1 || messages[0].content !== initialMessage.content) {
      localStorage.setItem("nimzz_chat_history", JSON.stringify(messages));
    }
  }, [messages]);

  const handleClearChat = () => {
    setMessages([initialMessage]);
    localStorage.removeItem("nimzz_chat_history");
    setShowClearConfirm(false);
  };

  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const [isMobile, setIsMobile] = useState(false);
  const lastSentRef = useRef(0);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 480);
    checkMobile();
    window.addEventListener("resize", checkMobile);

    const initDelay = setTimeout(() => {
      fetch("/api/chat?githubStats=true")
        .then((res) => res.json())
        .then((data) => {
          setGithubStats(data.stats);
          const fetchedRepos = (data.projects || []).map((repo) => ({
            ...repo,
            priority: 10,
          }));
          const signatureLinks = [
            {
              title: "GitHub Profile",
              github_url: config.contact.github.href,
              priority: 1,
              isSignature: true,
            },
          ];
          setProjects([...fetchedRepos, ...signatureLinks]);
        })
        .catch((err) => console.error("Chat info fetch error:", err));
    }, 1500);

    return () => {
      window.removeEventListener("resize", checkMobile);
      clearTimeout(initDelay);
    };
  }, []);

  useEffect(() => {
    if (!isMobile || !isOpen) {
      document.body.style.overflow = "";
      return;
    }

    document.body.style.overflow = "hidden";

    const handleViewportChange = () => {
      if (window.visualViewport) {
        setVpHeight(`${window.visualViewport.height}px`);
      }
    };

    if (window.visualViewport) {
      window.visualViewport.addEventListener("resize", handleViewportChange);
      window.visualViewport.addEventListener("scroll", handleViewportChange);
      handleViewportChange();
    }

    return () => {
      document.body.style.overflow = "";
      if (window.visualViewport) {
        window.visualViewport.removeEventListener(
          "resize",
          handleViewportChange,
        );
        window.visualViewport.removeEventListener(
          "scroll",
          handleViewportChange,
        );
      }
    };
  }, [isMobile, isOpen]);

  useEffect(() => {
    if (isMobile && isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [isMobile, isOpen]);

  useEffect(() => {
    const nudgeTimer = setTimeout(() => {
      const hasSeenNudge = sessionStorage.getItem("hasSeenAInudge");
      if (!isOpenRef.current && !hasSeenNudge) {
        setShowNudge(true);
        sessionStorage.setItem("hasSeenAInudge", "true");
      }
    }, 5000);

    return () => clearTimeout(nudgeTimer);
  }, []);

  const getStatusColor = () => "#22c55e";

  const getStatusText = () => "Tanya Aiko";

  const isUserInteracting = useRef(false);
  const userHasScrolledUp = useRef(false);

  const scrollToBottom = (instant = false, force = false) => {
    if (!isOpen || !scrollRef.current) return;

    const container = scrollRef.current;
    const distanceFromBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight;

    if (!force) {
      if (isUserInteracting.current) return;
      if (userHasScrolledUp.current && distanceFromBottom > 50) return;
      if (distanceFromBottom > 80) return;
    }

    isAutoScrolling.current = true;

    const performScroll = () => {
      if (instant) {
        container.scrollTop = container.scrollHeight;
      } else {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: "smooth",
        });
      }

      setTimeout(() => {
        isAutoScrolling.current = false;
      }, 150);
    };

    requestAnimationFrame(performScroll);
  };

  const prevMessagesLengthRef = useRef(0);

  useEffect(() => {
    const isNewMessage = messages.length !== prevMessagesLengthRef.current;
    scrollToBottom(isLoading, isNewMessage || isLoading);
    prevMessagesLengthRef.current = messages.length;
  }, [messages, isLoading]);

  const streamBufferRef = useRef("");

  const sendMessage = async (messageText) => {
    const content = messageText || input;
    if (!content.trim() || isLoading) return;

    lastSentRef.current = Date.now();

    const userMessage = {
      role: "user",
      content: content,
      timestamp: new Date().toISOString(),
    };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    if (!messageText) setInput("");
    setIsLoading(true);
    streamBufferRef.current = "";

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages
            .slice(-10)
            .map(({ role, content }) => ({ role, content })),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.error ||
            "Duh, koneksinya lagi bermasalah nih. Coba lagi sebentar ya.",
        );
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        streamBufferRef.current += chunk;
        setStreamingText(streamBufferRef.current);
      }

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: streamBufferRef.current,
          timestamp: new Date().toISOString(),
        },
      ]);
      setStreamingText("");
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            error.message ||
            "Sorry, I'm experiencing some connectivity issues. Please try again later.",
          timestamp: new Date().toISOString(),
        },
      ]);
      setStreamingText("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage();
  };

  const suggestions = [
    { label: "Siapa Rivan?", value: "Siapa itu Rivan?" },
    {
      label: "List Project",
      value: "Coba kasih list project WhatsApp bot yang pernah dibuat Rivan.",
    },
    {
      label: "Bahasa Pemrograman",
      value: "Bahasa pemrograman apa aja yang dikuasai Rivan?",
    },
    {
      label: "Tools",
      value: "Rivan coding dan editing pakai aplikasi apa?",
    },
    {
      label: "Skill",
      value: "Seberapa jago Rivan di coding dan editing?",
    },
    {
      label: "Update GitHub",
      value: "Apa 3 commit terbaru Rivan di GitHub?",
    },
    {
      label: "Kolaborasi",
      value: "Apakah Rivan terbuka untuk kolaborasi project?",
    },
    {
      label: "Kontak",
      value: "Gimana cara menghubungi developer portfolio ini?",
    },
    {
      label: "Fitur Website",
      value: "Apa saja fitur utama website portfolio ini?",
    },
  ];

  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const scrollRef = useRef(null);
  const isAutoScrolling = useRef(false);

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottom(distanceFromBottom > 150);

    if (isAutoScrolling.current) return;

    if (distanceFromBottom > 80) {
      userHasScrolledUp.current = true;
    } else if (distanceFromBottom < 10) {
      userHasScrolledUp.current = false;
    }
  };
  const handleSuggestion = (val) => {
    sendMessage(val);
  };

  const findProjectInText = (text) => {
    if (!projects || projects.length === 0) return null;
    const lowerText = text.toLowerCase();

    const scoredMatches = projects
      .map((p) => {
        const title = p.title.toLowerCase();
        const shortName = title.split("-")[0];

        if (lowerText.includes(title))
          return { project: p, score: 100 + title.length + p.priority * 10 };

        if (
          shortName.length >= 3 &&
          new RegExp(`\\b${shortName}\\b`, "i").test(lowerText)
        )
          return { project: p, score: 50 + shortName.length + p.priority * 10 };

        return { project: p, score: 0 };
      })
      .filter((m) => m.score > 0);

    if (scoredMatches.length === 0) return null;

    return scoredMatches.sort((a, b) => b.score - a.score)[0].project;
  };

  const CodeBlock = ({ code, lang }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
      navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };

    return (
      <div className={styles.codeBlock}>
        <div className={styles.codeHeader}>
          <div className={styles.windowControls}>
            <span className={styles.dotRed}></span>
            <span className={styles.dotYellow}></span>
            <span className={styles.dotGreen}></span>
          </div>
          <span className={styles.codeLang}>{lang || "code"}</span>
          <button
            className={styles.copyBtn}
            onClick={handleCopy}
            title="Copy code"
          >
            {copied ? (
              <span className={styles.copyFeedback}>Copied!</span>
            ) : (
              <i className="fa-regular fa-copy" aria-hidden="true" />
            )}
          </button>
        </div>
        <div className={styles.codeContent}>
          <SyntaxHighlighter
            language={(lang || "javascript").toLowerCase()}
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              padding: "20px 16px",
              background: "transparent",
              fontSize: "0.85rem",
              lineHeight: "1.7",
            }}
            codeTagProps={{
              style: {
                background: "transparent",
                fontFamily: "inherit",
              },
            }}
            lineNumberStyle={{
              color: "rgba(255,255,255,0.25)",
              minWidth: "3em",
              paddingRight: "1.2em",
              textAlign: "right",
              fontSize: "0.75rem",
              userSelect: "none",
              borderRight: "1px solid rgba(255,255,255,0.05)",
              marginRight: "12px",
              background: "transparent",
            }}
            showLineNumbers={true}
            wrapLines={true}
            lineProps={{
              style: {
                display: "flex",
                alignItems: "center",
              },
            }}
          >
            {code.replace(/`+$/, "").trim()}
          </SyntaxHighlighter>
        </div>
      </div>
    );
  };

  const MarkdownBody = ({ content }) => {
    const formatted = content
      .replace(/(?<!\()https?:\/\/[^\s\)]+/g, (url) => `[${url}](${url})`)
      .replace(/^(\s*[-*•]\s+)(?!\*\*)([^:\n*]+?)\s*:/gm, "$1**$2**:");

    return (
      <div className={styles.msgText}>
        <ReactMarkdown
          remarkPlugins={[remarkGfm, remarkBreaks]}
          components={{
            a({ href, children, ...props }) {
              const isInternal = href && href.startsWith("/");
              return (
                <a
                  href={href}
                  target={isInternal ? undefined : "_blank"}
                  rel={isInternal ? undefined : "noopener noreferrer"}
                  {...props}
                >
                  {children}
                </a>
              );
            },
            code({ node, inline, className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || "");
              if (inline || !match) {
                return (
                  <code className={className} {...props}>
                    {children}
                  </code>
                );
              }
              return (
                <CodeBlock
                  code={String(children).replace(/\n$/, "")}
                  lang={match[1]}
                />
              );
            },
          }}
        >
          {formatted}
        </ReactMarkdown>
      </div>
    );
  };

  const StreamingWords = ({ text }) => {
    const clean = text
      .replace(/<think>[\s\S]*?(<\/think>|$)/gi, "")
      .trim();
    const words = clean.length ? clean.split(" ") : [];

    return (
      <div className={styles.msgText}>
        {words.map((w, i) => (
          <span key={i} className={styles.fadeWord}>
            {w}
            {i < words.length - 1 ? " " : ""}
          </span>
        ))}
        <span className={styles.streamCursor} />
      </div>
    );
  };

  const formatTime = (isoString) => {
    if (!isoString) return "";
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));

      const timeStr = date.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });

      const isToday = date.toDateString() === now.toDateString();

      const yesterday = new Date();
      yesterday.setDate(now.getDate() - 1);
      const isYesterday = date.toDateString() === yesterday.toDateString();

      if (isToday) return `Today, ${timeStr}`;
      if (isYesterday) return `Yesterday, ${timeStr}`;
      if (diffInDays < 7) {
        return `${date.toLocaleDateString("en-US", { weekday: "short" })}, ${timeStr}`;
      }
      return `${date.toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit" })}, ${timeStr}`;
    } catch (e) {
      return "";
    }
  };

  const renderMessageContent = (rawContent, role) => {
    // Hide reasoning <think> blocks from models like Qwen
    const content = rawContent
      .replace(/<think>[\s\S]*?(<\/think>|$)/gi, "")
      .trim();

    if (role !== "assistant") return <MarkdownBody content={content} />;

    const lowerContent = content.toLowerCase();

    const hasStats =
      githubStats &&
      (lowerContent.includes("stats") ||
        lowerContent.includes("milestone") ||
        lowerContent.includes("total stars") ||
        lowerContent.includes("statistik") ||
        lowerContent.includes("overview") ||
        (lowerContent.includes("repos") && lowerContent.includes("stars")));

    const project = findProjectInText(content);

    return (
      <div className={styles.msgContentWrapper}>
        <MarkdownBody content={content} />

        {hasStats && content.length > 15 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={styles.statsGrid}
          >
            <div className={styles.statItem}>
              <span className={styles.statVal}>{githubStats.public_repos}</span>
              <span className={styles.statLabel}>Repos</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statVal}>{githubStats.total_stars}</span>
              <span className={styles.statLabel}>Stars</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statVal}>{githubStats.total_forks}</span>
              <span className={styles.statLabel}>Forks</span>
            </div>
          </motion.div>
        )}

        {project && project.stars !== undefined && content.length > 15 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={styles.statsGrid}
          >
            <div className={styles.statItem}>
              <span className={styles.statVal}>
                {project.language || "N/A"}
              </span>
              <span className={styles.statLabel}>Lang</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statVal}>{project.stars || 0}</span>
              <span className={styles.statLabel}>Stars</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statVal}>{project.forks || 0}</span>
              <span className={styles.statLabel}>Forks</span>
            </div>
          </motion.div>
        )}

        {project && content.length > 15 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={styles.projectCard}
          >
            <span>
              Context Link: <strong>{project.title}</strong>
            </span>
            <a
              href={
                project.github_url ||
                project.path ||
                `${config.contact.github.href}/${project.title}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className={styles.projectLink}
            >
              View Repository
              <i className="fa-solid fa-arrow-up-right-from-square" aria-hidden="true" />
            </a>
          </motion.div>
        )}
      </div>
    );
  };

  const handleToggle = () => {
    if (!isOpen) {
      setShowNudge(false);
      sessionStorage.setItem("hasSeenAInudge", "true");
    }
    setIsOpen(!isOpen);
  };

  return (
    <div className={styles.chatWrapper}>
      <AnimatePresence>
        {showNudge && !isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            className={styles.nudgeBubble}
            onClick={handleToggle}
          >
            Butuh bantuan? Chat yuk!
            <div className={styles.nudgeArrow} />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={
              isMobile
                ? { opacity: 0, y: "100%" }
                : { opacity: 0, y: 20, scale: 0.95 }
            }
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={
              isMobile
                ? { opacity: 0, y: "100%" }
                : { opacity: 0, y: 20, scale: 0.95 }
            }
            transition={
              isMobile
                ? { type: "tween", duration: 0.36, ease: [0.23, 1, 0.32, 1] }
                : { type: "spring", damping: 28, stiffness: 220 }
            }
            className={styles.chatWindow}
            style={isMobile ? { height: vpHeight, top: 0, bottom: "auto" } : {}}
          >
            <div className={styles.header}>
              <div className={styles.headerTitle}>
                <div
                  className={styles.statusDot}
                  style={{
                    backgroundColor: getStatusColor(),
                    boxShadow: `0 0 8px ${getStatusColor()}80`,
                  }}
                />
                <h4>{getStatusText()}</h4>
              </div>
              <div className={styles.headerActions}>
                <button
                  className={styles.resetButton}
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowClearConfirm(true);
                  }}
                  title="Clear conversation"
                >
                  <i className="fa-regular fa-trash-can" aria-hidden="true" />
                </button>
                <button className={styles.closeButton} onClick={handleToggle}>
                  <i className="fa-solid fa-xmark" aria-hidden="true" />
                </button>
              </div>
            </div>

            <div className={styles.messagesWrapper}>
              <div
                className={styles.messages}
                style={{
                  overflowY: "auto",
                  WebkitOverflowScrolling: "touch",
                  touchAction: "pan-y",
                  overscrollBehavior: "contain",
                }}
                data-lenis-prevent
                onScroll={handleScroll}
                onWheel={() => {
                  isUserInteracting.current = true;
                  setTimeout(() => (isUserInteracting.current = false), 1000);
                }}
                onTouchStart={() => {
                  isUserInteracting.current = true;
                }}
                onTouchEnd={() => {
                  setTimeout(() => (isUserInteracting.current = false), 1000);
                }}
                ref={scrollRef}
              >
                <div className={styles.messagesContainer}>
                  {messages.map((msg, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                      className={`${styles.message} ${
                        msg.role === "user" ? styles.user : styles.ai
                      }`}
                    >
                      {msg.role === "assistant" && (
                        <div className={styles.avatarWrapper}>
                          <img
                            src={config.aiAvatarUrl}
                            alt="Aiko"
                            className={styles.avatar}
                            width={20}
                            height={20}
                          />
                        </div>
                      )}
                      <div className={styles.messageContent}>
                        {renderMessageContent(msg.content, msg.role)}
                        <span className={styles.timestamp}>
                          {formatTime(msg.timestamp)}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                  <AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25, ease: "easeInOut" }}
                        className={`${styles.message} ${styles.ai}`}
                      >
                        <div
                          className={`${styles.avatarWrapper} ${styles.loadingAvatar}`}
                        >
                          <img
                            src={config.aiAvatarUrl}
                            alt="Aiko"
                            className={styles.avatar}
                            width={20}
                            height={20}
                          />
                        </div>
                        {streamingText.trim() ? (
                          <div className={styles.messageContent}>
                            <StreamingWords text={streamingText} />
                          </div>
                        ) : (
                          <div
                            className={`${styles.messageContent} ${styles.loading}`}
                          >
                            <span className={styles.loadingText}>Mikir</span>
                            <div className={styles.typingIndicator}>
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {showScrollBottom && (
                <button
                  className={styles.scrollToBottom}
                  onClick={() => {
                    scrollToBottom(false, true);
                    setShowScrollBottom(false);
                  }}
                  aria-label="Scroll to bottom"
                >
                  <i className="fa-solid fa-chevron-down" aria-hidden="true" />
                </button>
              )}
            </div>

            <div className={styles.inputContainer}>
              <div className={styles.suggestions} data-lenis-prevent>
                {suggestions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => handleSuggestion(s.value)}
                    disabled={isLoading}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
              <form
                id="ai-chat-form"
                className={styles.inputArea}
                onSubmit={handleSubmit}
              >
                <input
                  type="text"
                  placeholder={
                    isLoading ? "AI is thinking..." : "Ask anything..."
                  }
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  className={styles.sendButton}
                  disabled={isLoading || !input.trim()}
                >
                  <i className="fa-solid fa-paper-plane" aria-hidden="true" />
                </button>
              </form>
            </div>

            <AnimatePresence>
              {showClearConfirm && (
                <motion.div
                  className={styles.clearOverlay}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <motion.div
                    className={styles.clearModal}
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                  >
                    <p>Reset chat history?</p>
                    <div className={styles.modalActions}>
                      <button
                        className={styles.cancelBtn}
                        onClick={() => setShowClearConfirm(false)}
                      >
                        No
                      </button>
                      <button
                        className={styles.confirmBtn}
                        onClick={handleClearChat}
                      >
                        Yes
                      </button>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        className={`${styles.chatButton} ${isOpen ? styles.menuOpen : ""}`}
        onClick={handleToggle}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.9 }}
        aria-label={isOpen ? "Close AI Assistant" : "Open AI Assistant"}
      >
        <div className={styles.iconContainer}>
          <motion.div
            animate={{
              opacity: isOpen ? 0 : 1,
              scale: isOpen ? 0.5 : 1,
              rotate: isOpen ? -90 : 0,
            }}
            transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
            className={styles.iconWrapper}
          >
            <i
              className={`fa-solid fa-comment-dots ${styles.buttonIcon}`}
              aria-hidden="true"
            />
          </motion.div>

          <div className={styles.burgerContainer}>
            <span className={styles.burgerLine} />
            <span className={styles.burgerLine} />
            <span className={styles.burgerLine} />
          </div>
        </div>
      </motion.button>
    </div>
  );
}
