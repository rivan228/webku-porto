"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import styles from "./Navbar.module.css";
import config from "@/lib/config";
import { useTheme } from "./ThemeProvider";

const links = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/projects", label: "Projects" },
  { href: "/bot", label: "Bot Simulator" },
  { href: "/aiko", label: "Aiko Live" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const { theme, toggleTheme, mounted } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <>
      <motion.header
        className={`${styles.navbar} ${scrolled ? styles.scrolled : ""}`}
      >
        <div className={styles.inner}>
          <Link href="/" className={styles.logo}>
            <img
              src={config.logoUrl}
              alt={config.name}
              className={styles.logoIcon}
              width={28}
              height={28}
            />
            <span>{config.name}</span>
          </Link>

          <nav className={styles.nav}>
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`${styles.navLink} ${pathname === link.href ? styles.active : ""}`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className={styles.actions}>
            <a
              href={config.contact.github.href}
              target="_blank"
              rel="noopener noreferrer"
              className={styles.githubBtn}
              aria-label="GitHub Profile"
            >
              <i className="fa-brands fa-github" aria-hidden="true" />
              <span>RivanAI</span>
            </a>

            <button
              type="button"
              className={styles.themeToggle}
              onClick={toggleTheme}
              aria-label={
                theme === "dark" ? "Aktifkan mode terang" : "Aktifkan mode gelap"
              }
            >
              {mounted && (
                <i
                  className={
                    theme === "dark" ? "fa-solid fa-sun" : "fa-solid fa-moon"
                  }
                  aria-hidden="true"
                />
              )}
            </button>

            <button
              className={`${styles.menuBtn} ${menuOpen ? styles.menuOpen : ""}`}
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
            >
              <span className={styles.menuLine} />
              <span className={styles.menuLine} />
              <span className={styles.menuLine} />
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className={styles.mobileMenu}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {links.map((link, i) => (
              <motion.div
                key={link.href}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.3 }}
              >
                <Link
                  href={link.href}
                  className={`${styles.mobileLink} ${pathname === link.href ? styles.active : ""}`}
                >
                  {link.label}
                </Link>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: links.length * 0.05, duration: 0.3 }}
              style={{ display: "flex", gap: "12px", marginTop: "16px" }}
            >
              <a
                href={config.contact.github.href}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.githubBtn}
                style={{ display: "inline-flex" }}
              >
                <i className="fa-brands fa-github" aria-hidden="true" />
                <span>GitHub RivanAI</span>
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
