"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import styles from "./BotSimulator.module.css";
import config from "@/lib/config";

const initialMessages = [
  {
    id: 1,
    sender: "bot",
    time: "10:00",
    text: "Halo! Selamat datang di DevPortfolio AI Bot Simulator (Unlimited Chat AI Engine). Ketik .menu untuk daftar perintah, ketik .status untuk cek status server, atau langsung tanyakan apa saja ke AI!",
  },
];

const quickCommands = [
  { label: ".menu", cmd: ".menu" },
  { label: "⚡ .speed", cmd: ".speed" },
  { label: ".status", cmd: ".status" },
  { label: ".owner", cmd: ".owner" },
  { label: "Tanya AI: Info Portfolio", cmd: "Jelaskan tentang template DevPortfolio dan keahlian developernya!" },
  { label: "Tanya AI: Fitur Website Ini", cmd: "Jelaskan apa saja fitur-fitur dan teknologi yang ada di website portfolio modern ini!" },
];

export default function BotSimulator() {
  const [messages, setMessages] = useState(initialMessages);
  const [inputVal, setInputVal] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatAreaRef = useRef(null);
  const idCounter = useRef(20);
  const abortControllerRef = useRef(null);

  const scrollChatToBottom = useCallback((smooth = true) => {
    const el = chatAreaRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth ? "smooth" : "auto",
    });
  }, []);

  useEffect(() => {
    // Only scroll internally inside chatArea container, never scrolls the window/page
    scrollChatToBottom(true);
  }, [messages, isTyping, scrollChatToBottom]);

  const getCurrentTime = () => {
    const d = new Date();
    return d.toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
  };

  const askBotAI = async (userPrompt, currentHistory) => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    idCounter.current += 1;
    const botMsgId = idCounter.current;
    const timeNow = getCurrentTime();

    setIsTyping(true);

    try {
      const apiMessages = currentHistory
        .slice(-8)
        .map((m) => ({
          role: m.sender === "user" ? "user" : "assistant",
          content: m.text,
        }));

      const res = await fetch("/api/bot-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages }),
        signal: controller.signal,
      });

      if (!res.ok) {
        throw new Error(`HTTP error: ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let hasReceivedData = false;

      // Add the bot message placeholder once streaming starts or when first chunk arrives
      setMessages((prev) => [
        ...prev,
        {
          id: botMsgId,
          sender: "bot",
          time: timeNow,
          text: "",
        },
      ]);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        if (chunk) {
          hasReceivedData = true;
          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === botMsgId ? { ...msg, text: (msg.text || "") + chunk } : msg
            )
          );
        }
      }

      if (!hasReceivedData) {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === botMsgId
              ? {
                  ...msg,
                  text: "⚡ *AI ASSISTANT:* Pesan diterima! Ketik *.menu* untuk melihat perintah atau tanyakan apa saja seputar coding/teknologi.",
                }
              : msg
          )
        );
      }
    } catch (err) {
      if (err.name === "AbortError") return;
      console.error("AI error:", err);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === botMsgId
            ? {
                ...msg,
                text: "⚡ *AI BOT*\n\nMaaf, koneksi AI sedang sibuk. Silakan coba kirim lagi atau ketik *.menu* / *.status*.",
              }
            : msg
        )
      );
    } finally {
      setIsTyping(false);
    }
  };

  const handleCommand = (cmdText) => {
    const trimmed = cmdText.trim();
    if (!trimmed) return;

    idCounter.current += 1;
    const userMsgId = idCounter.current;
    const timeNow = getCurrentTime();

    const userMsg = {
      id: userMsgId,
      sender: "user",
      time: timeNow,
      text: trimmed,
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInputVal("");
    setIsTyping(true);

    const lower = trimmed.toLowerCase();

    if (lower === ".menu" || lower === "menu") {
      setTimeout(() => {
        idCounter.current += 1;
        setMessages((prev) => [
          ...prev,
          {
            id: idCounter.current,
            sender: "bot",
            time: getCurrentTime(),
            text:
              `⚡ *DEVPORTFOLIO AI BOT SIMULATOR*\n\n` +
              `👑 *Persona:* DevPortfolio Showcase\n` +
              `📍 *Hub / Lokasi:* Tulungagung, Jawa Timur\n` +
              `🚀 *Engine:* Unlimited Chat AI Architecture\n\n` +
              `📂 *DAFTAR PERINTAH:*\n` +
              `▸ *.status* - Cek performa server AI & latency\n` +
              `▸ *.speed* - Tes latency respons bot\n` +
              `▸ *.owner* - Info developer & kontak portofolio\n` +
              `▸ *Chat Bebas / Tanya AI* - Tanyakan seputar coding, solusi web, curhat, matematika, atau bantuan teknis 24/7!`,
          },
        ]);
        setIsTyping(false);
      }, 350);
      return;
    }

    if (lower === ".status" || lower === "status") {
      setTimeout(() => {
        idCounter.current += 1;
        setMessages((prev) => [
          ...prev,
          {
            id: idCounter.current,
            sender: "bot",
            time: getCurrentTime(),
            text:
              `📊 *SYSTEM STATUS - RIVAN AI BOT*\n\n` +
              `▸ Status: *ONLINE 24/7 (Aktif)*\n` +
              `▸ AI Engine: Unlimited Chat AI (Real-time Stream)\n` +
              `▸ Latency: Fast Response (< 40ms)\n` +
              `▸ Environment: Next.js 15 Edge & Node.js Runtime\n` +
              `▸ Device Dev: Android Phone (Termux Linux + Acode)`,
          },
        ]);
        setIsTyping(false);
      }, 300);
      return;
    }

    if (lower === ".speed" || lower === "speed" || lower === ".ping") {
      setTimeout(() => {
        idCounter.current += 1;
        setMessages((prev) => [
          ...prev,
          {
            id: idCounter.current,
            sender: "bot",
            time: getCurrentTime(),
            text: `⚡ *PONG!*\nKecepatan respons: *9ms*\nAI Engine: *Online & Streaming*\nServer Status: *Optimal*`,
          },
        ]);
        setIsTyping(false);
      }, 250);
      return;
    }

    if (lower === ".owner" || lower === "owner") {
      setTimeout(() => {
        idCounter.current += 1;
        setMessages((prev) => [
          ...prev,
          {
            id: idCounter.current,
            sender: "bot",
            time: getCurrentTime(),
            text:
              `👤 *DEVELOPER & SHOWCASE INFO*\n\n` +
              `▸ Project: DevPortfolio (Modern Example Portfolio)\n` +
              `▸ Peran: Fullstack & WhatsApp Bot Developer\n` +
              `▸ Domisili: Tulungagung, Jawa Timur\n` +
              `▸ WhatsApp: +62 821-3748-7477\n` +
              `▸ Telegram: @Nimzz4\n` +
              `▸ GitHub: github.com/NimzzAI\n\n` +
              `💡 _Silakan jelajahi fitur website, tanya AI, atau hubungi kontak di atas untuk kolaborasi._`,
          },
        ]);
        setIsTyping(false);
      }, 300);
      return;
    }

    const cleanPrompt = trimmed.replace(/^\.ai\s+/i, "");
    askBotAI(cleanPrompt, nextHistory);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleCommand(inputVal);
  };

  return (
    <div className={styles.wrapper}>
      <div className={styles.phoneHeader}>
        <div className={styles.botAvatar}>
          <i className="fa-solid fa-robot" />
        </div>
        <div className={styles.headerInfo}>
          <div className={styles.botNameRow}>
            <span className={styles.botName}>DevPortfolio AI Bot</span>
            <span className={styles.verifiedBadge}>
              <i className="fa-solid fa-circle-check" />
            </span>
          </div>
          <span className={styles.botStatus}>
            {isTyping ? (
              <span className={styles.botTypingStatus}>
                <span className={styles.statusPulseDot} />
                AI sedang mengetik balasan...
              </span>
            ) : (
              "Online • Unlimited AI Engine ⚡"
            )}
          </span>
        </div>
        <a
          href={config.contact.whatsapp.href}
          target="_blank"
          rel="noopener noreferrer"
          className={styles.realOrderBtn}
          title="Hubungi Developer via WhatsApp"
        >
          <i className="fa-brands fa-whatsapp" />
          <span>Kontak</span>
        </a>
      </div>

      <div ref={chatAreaRef} className={styles.chatArea}>
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                duration: 0.24,
                ease: [0.16, 1, 0.3, 1],
              }}
              className={`${styles.bubbleRow} ${
                m.sender === "user" ? styles.bubbleUser : styles.bubbleBot
              }`}
            >
              <div className={`${styles.bubble} ${m.sender === "bot" && !m.text ? styles.typingResponseBubble : ""}`}>
                <div className={styles.bubbleText}>
                  {m.text ? (
                    <>
                      {m.text.split("\n").map((line, i) => (
                        <React.Fragment key={i}>
                          {line}
                          {i < m.text.split("\n").length - 1 && <br />}
                        </React.Fragment>
                      ))}
                      {/* Typing cursor effect on the latest active bot response if it's currently receiving tokens */}
                      {m.sender === "bot" && m.id === messages[messages.length - 1]?.id && isTyping && (
                        <span className={styles.typingCursor} aria-hidden="true" />
                      )}
                    </>
                  ) : (
                    <span className={styles.streamingTypingPlaceholder}>
                      <span className={styles.typingDotSmall} />
                      <span className={styles.typingDotSmall} />
                      <span className={styles.typingDotSmall} />
                      <span>Mengetik respon...</span>
                    </span>
                  )}
                </div>
                <div className={styles.metaRow}>
                  <span className={styles.time}>{m.time}</span>
                  {m.sender === "user" && (
                    <span className={styles.checkmarks}>
                      <i className="fa-solid fa-check-double" />
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div
              key="typing-indicator"
              initial={{ opacity: 0, y: 10, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{
                duration: 0.2,
                ease: [0.16, 1, 0.3, 1],
              }}
              className={`${styles.bubbleRow} ${styles.bubbleBot}`}
            >
              <div className={`${styles.bubble} ${styles.typingBubble}`}>
                <div className={styles.typingContent}>
                  <div className={styles.typingHeaderRow}>
                    <i className="fa-solid fa-wand-magic-sparkles" style={{ color: "var(--accent)" }} />
                    <span className={styles.typingText}>RivanAI is typing...</span>
                  </div>
                  <div className={styles.dotsContainer}>
                    <span className={styles.typingDot} />
                    <span className={styles.typingDot} />
                    <span className={styles.typingDot} />
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className={styles.quickCommandsRow}>
        <span className={styles.quickTitle}>Perintah Cepat:</span>
        <div className={styles.quickChips}>
          {quickCommands.map((q) => (
            <button
              key={q.label}
              type="button"
              className={styles.quickBtn}
              onClick={() => handleCommand(q.cmd)}
            >
              {q.label}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className={styles.inputArea}>
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Ketik perintah (.menu, .status) atau tanya apa saja ke AI..."
          className={styles.chatInput}
        />
        <button
          type="submit"
          className={styles.sendBtn}
          aria-label="Kirim perintah"
          disabled={!inputVal.trim()}
        >
          <i className="fa-solid fa-paper-plane" />
        </button>
      </form>
    </div>
  );
}
