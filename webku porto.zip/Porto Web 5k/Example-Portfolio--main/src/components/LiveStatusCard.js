"use client";

import Image from "next/image";
import { useState, useEffect } from "react";
import styles from "./LiveStatusCard.module.css";
import config from "@/lib/config";

const activities = [
  {
    label: "CODING",
    value: config.codingApp.name,
    detail: "Ngoprek WhatsApp bot dari HP",
    image: config.codingApp.icon,
  },
  {
    label: "EDITING",
    value: config.editingApp.name,
    detail: "Lagi bikin project edit baru",
    image: config.editingApp.icon,
  },
  {
    label: "STATUS",
    value: config.status,
    detail: config.major,
    icon: "fa-solid fa-graduation-cap",
  },
];

export default function LiveStatusCard() {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % activities.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const activity = activities[activeIndex];
  const avatarSrc = config.profile?.avatarUrl || config.avatar;
  const bannerSrc = config.profile?.bannerUrl;
  const isBannerVideo =
    bannerSrc && /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(bannerSrc);

  return (
    <div className={styles.card}>
      {bannerSrc && (
        <div className={styles.bannerWrapper}>
          {isBannerVideo ? (
            <video
              className={styles.banner}
              src={bannerSrc}
              autoPlay
              loop
              muted
              playsInline
            />
          ) : (
            <img src={bannerSrc} alt="" className={styles.banner} />
          )}
        </div>
      )}

      <div className={styles.cardContent}>
        <div className={styles.topInfo}>
          <div className={styles.dotWrapper}>
            <span className={styles.dotPulse} style={{ background: "#22c55e" }} />
            <span className={styles.dot} style={{ background: "#22c55e" }} />
          </div>
          <span className={styles.statusText}>LIVE STATUS</span>
          <div className={styles.liveIndicator}>
            <span className={styles.liveLabel}>ON</span>
            <div className={styles.signal}>
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>

        <div className={styles.profileSection}>
          <div className={styles.avatarWrapper}>
            {config.profile?.avatarUrl ? (
              <img src={avatarSrc} alt={config.name} className={styles.avatar} />
            ) : (
              <Image
                src={avatarSrc}
                alt={config.name}
                width={48}
                height={48}
                className={styles.avatar}
              />
            )}
          </div>
          <div className={styles.info}>
            <p className={styles.name}>{config.name}</p>
            <p className={styles.customStatus}>{config.tagline}</p>
          </div>
        </div>

        <div className={styles.activitySection}>
          <div className={styles.activityBox}>
            <div className={styles.activityItem}>
              <div className={styles.activityIcon}>
                {activity.image ? (
                  <img
                    src={activity.image}
                    alt={activity.value}
                    className={styles.activityImage}
                  />
                ) : (
                  <i className={activity.icon} />
                )}
              </div>
              <div className={styles.activityText}>
                <span className={styles.activityLabel}>{activity.label}</span>
                <span className={styles.activityValue}>{activity.value}</span>
                <span className={styles.activityDetail}>{activity.detail}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
