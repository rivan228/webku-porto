"use client";

import styles from "./Footer.module.css";
import config from "@/lib/config";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <p className={styles.copy}>
          © {new Date().getFullYear()} {config.name}. All rights reserved.
        </p>

        <div className={styles.links}>
          <a
            href={config.contact.github.href}
            target="_blank"
            rel="noopener noreferrer"
            className={styles.link}
          >
            <i className="fa-brands fa-github" /> GitHub
          </a>
          <button onClick={scrollToTop} className={styles.backTop}>
            <i className="fa-solid fa-arrow-up" /> Back to top
          </button>
        </div>
      </div>
    </footer>
  );
}
