"use client";

import { createContext, useContext, useEffect, useState, useCallback } from "react";

const STORAGE_KEY = "theme"; // "light" | "dark" — only written once the user manually toggles
const MODE_KEY = "theme-mode"; // "system" | "manual"

const ThemeContext = createContext({
  theme: "dark",
  isSystemTheme: true,
  toggleTheme: () => {},
  useSystemTheme: () => {},
  mounted: false,
});

function getSystemTheme() {
  return window.matchMedia("(prefers-color-scheme: light)").matches
    ? "light"
    : "dark";
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("dark");
  const [isSystemTheme, setIsSystemTheme] = useState(true);
  const [mounted, setMounted] = useState(false);

  // Initial resolve: manual choice (if any) wins, otherwise follow the OS.
  useEffect(() => {
    const mode = window.localStorage.getItem(MODE_KEY);
    const stored = window.localStorage.getItem(STORAGE_KEY);

    let resolved;
    let fromSystem;

    if (mode === "manual" && (stored === "light" || stored === "dark")) {
      resolved = stored;
      fromSystem = false;
    } else {
      resolved = getSystemTheme();
      fromSystem = true;
    }

    setTheme(resolved);
    setIsSystemTheme(fromSystem);
    document.documentElement.setAttribute("data-theme", resolved);
    setMounted(true);
  }, []);

  // While following the system, keep syncing live if the user flips their
  // OS/browser theme without ever touching our toggle.
  useEffect(() => {
    if (!mounted) return;
    const mq = window.matchMedia("(prefers-color-scheme: light)");

    const handleChange = (e) => {
      setIsSystemTheme((currentlySystem) => {
        if (!currentlySystem) return currentlySystem;
        const next = e.matches ? "light" : "dark";
        setTheme(next);
        document.documentElement.setAttribute("data-theme", next);
        return currentlySystem;
      });
    };

    mq.addEventListener("change", handleChange);
    return () => mq.removeEventListener("change", handleChange);
  }, [mounted]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      window.localStorage.setItem(STORAGE_KEY, next);
      window.localStorage.setItem(MODE_KEY, "manual");
      setIsSystemTheme(false);
      return next;
    });
  }, []);

  // Lets a user opt back into following their OS theme (not currently wired
  // to any UI, but available for a future settings toggle).
  const useSystemTheme = useCallback(() => {
    window.localStorage.removeItem(STORAGE_KEY);
    window.localStorage.setItem(MODE_KEY, "system");
    const next = getSystemTheme();
    setTheme(next);
    setIsSystemTheme(true);
    document.documentElement.setAttribute("data-theme", next);
  }, []);

  return (
    <ThemeContext.Provider
      value={{ theme, isSystemTheme, toggleTheme, useSystemTheme, mounted }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
