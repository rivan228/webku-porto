"use client";

import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";

const MODEL_URL = "/live2d/icegirl/IceGirl.model3.json";
const CUBISM_CORE_URL =
  "https://cubism.live2d.com/sdk-web/cubismcore/live2dcubismcore.min.js";

function loadCubismCore() {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined") return reject(new Error("no window"));
    if (window.Live2DCubismCore) return resolve();

    const existing = document.querySelector(`script[src="${CUBISM_CORE_URL}"]`);
    if (existing) {
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () =>
        reject(new Error("Gagal load Cubism Core")),
      );
      return;
    }

    const script = document.createElement("script");
    script.src = CUBISM_CORE_URL;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Gagal load Cubism Core"));
    document.body.appendChild(script);
  });
}

/**
 * Panggung Live2D buat Aiko. Semua kerjaan berat (load PIXI, load model,
 * render loop) ada di sini. Parent ngontrol lewat ref:
 *   - stageRef.current.expression("blush")
 *   - stageRef.current.motion("Wave")
 *   - stageRef.current.singWithAudioEl(audioElement)
 *   - stageRef.current.stopSinging()
 *   - stageRef.current.captureDataURL() -> string dataURL PNG | null
 *
 * Tap/klik di badan model diteruskan ke `onHit` (bukan dipilih di sini) —
 * keputusan ekspresi apa yang muncul akibat tap itu sekarang jadi tanggung
 * jawab mood engine di parent (src/lib/aikoMood.js), bukan random di sini,
 * biar cuma ada SATU sumber kebenaran buat wajah Aiko.
 */
const Live2DStage = forwardRef(function Live2DStage({ onStatusChange, onHit }, ref) {
  const wrapRef = useRef(null);
  const canvasRef = useRef(null);
  const appRef = useRef(null);
  const modelRef = useRef(null);
  const naturalSizeRef = useRef({ w: 1, h: 1 });
  const onHitRef = useRef(onHit);
  onHitRef.current = onHit;
  const pendingExpressionRef = useRef(undefined);
  const hasPendingExpressionRef = useRef(false);

  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);
  const sourceMapRef = useRef(new WeakMap());
  const singingRef = useRef(false);
  const talkingRef = useRef(false);

  const [status, setStatus] = useState("loading");
  const [errorDetail, setErrorDetail] = useState("");

  useEffect(() => {
    onStatusChange?.(status);
  }, [status, onStatusChange]);

  useImperativeHandle(ref, () => ({
    expression(name) {
      if (modelRef.current) {
        modelRef.current.expression(name);
      } else {
        // Model belum siap — simpen, nanti di-apply pas load selesai.
        pendingExpressionRef.current = name;
        hasPendingExpressionRef.current = true;
      }
    },
    motion(group) {
      modelRef.current?.motion(group);
    },
    resetFace() {
      modelRef.current?.expression();
    },
    
    captureDataURL() {
      const app = appRef.current;
      if (!app || !modelRef.current) return null;
      try {
        const canvas = app.renderer.plugins.extract.canvas(app.stage);
        return canvas.toDataURL("image/png");
      } catch (err) {
        console.error("Gagal extract canvas Live2D:", err);
        return null;
      }
    },
    async singWithAudioEl(audioEl) {
      const model = modelRef.current;
      if (!model || !audioEl) return;

      if (!audioCtxRef.current) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") await ctx.resume();

      if (!sourceMapRef.current.has(audioEl)) {
        const source = ctx.createMediaElementSource(audioEl);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        source.connect(analyser);
        analyser.connect(ctx.destination);
        sourceMapRef.current.set(audioEl, analyser);
      }
      analyserRef.current = sourceMapRef.current.get(audioEl);
      dataArrayRef.current = new Uint8Array(
        analyserRef.current.frequencyBinCount,
      );
      singingRef.current = true;
      model.motion("Wave");
    },
    stopSinging() {
      singingRef.current = false;
      const model = modelRef.current;
      if (model?.internalModel?.coreModel) {
        model.internalModel.coreModel.setParameterValueById(
          "ParamMouthOpenY",
          0,
        );
      }
    },
    isSinging() {
      return singingRef.current;
    },
    talk(active) {
      talkingRef.current = active;
      if (!active) {
        const model = modelRef.current;
        if (model?.internalModel?.coreModel && !singingRef.current) {
          model.internalModel.coreModel.setParameterValueById(
            "ParamMouthOpenY",
            0,
          );
        }
      }
    },
  }));

  useEffect(() => {
    let destroyed = false;
    let removeResize = () => {};

    async function setup() {
      try {
        setStatus("loading");
        await loadCubismCore();
        if (destroyed) return;

        const PIXI = await import("pixi.js");
        window.PIXI = PIXI;

        const { install: installUnsafeEvalPatch } = await import(
          "@pixi/unsafe-eval"
        );
        installUnsafeEvalPatch(PIXI);

        const { Live2DModel } = await import("pixi-live2d-display/cubism4");
        if (destroyed) return;

        const app = new PIXI.Application({
          view: canvasRef.current,
          autoStart: true,
          backgroundAlpha: 0,
          antialias: true,
          resolution: Math.min(window.devicePixelRatio || 1, 1.5),
          autoDensity: true,
        });
        appRef.current = app;

        const model = await Live2DModel.from(MODEL_URL, {
          autoInteract: true,
        });
        if (destroyed) {
          model.destroy();
          app.destroy(true, { children: true });
          return;
        }

        modelRef.current = model;
        app.stage.addChild(model);

        if (hasPendingExpressionRef.current) {
          model.expression(pendingExpressionRef.current);
          hasPendingExpressionRef.current = false;
        }

        naturalSizeRef.current = { w: model.width || 1, h: model.height || 1 };

        const ANCHOR_Y = 0.5;
        const SCREEN_Y = 0.8;
        const TOP_MARGIN = 0.05;
        const MAX_WIDTH_FRACTION = 1.8;

        model.anchor.set(0.5, ANCHOR_Y);

        const fit = () => {
          const parent = wrapRef.current;
          if (!parent || !model) return;
          const w = parent.clientWidth;
          const h = parent.clientHeight;
          const { w: nw, h: nh } = naturalSizeRef.current;

          const renderedHeight = ((SCREEN_Y - TOP_MARGIN) * h) / ANCHOR_Y;
          let scale = renderedHeight / nh;

          const renderedWidth = nw * scale;
          const maxWidth = w * MAX_WIDTH_FRACTION;
          if (renderedWidth > maxWidth) scale = maxWidth / nw;

          model.scale.set(scale);
          model.x = w / 2;
          model.y = h * SCREEN_Y;
          app.renderer.resize(w, h);
        };
        fit();

        window.addEventListener("resize", fit);
        removeResize = () => window.removeEventListener("resize", fit);
        model.on("hit", () => {
          model.motion("Wave");
          onHitRef.current?.();
        });

        app.ticker.add(() => {
          const core = model.internalModel?.coreModel;
          if (!core) return;

          if (singingRef.current && analyserRef.current) {
            const analyser = analyserRef.current;
            const dataArray = dataArrayRef.current;
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i += 1) sum += dataArray[i];
            const avg = sum / dataArray.length;
            const value = Math.min(1, (avg / 255) * 3.2);
            core.setParameterValueById("ParamMouthOpenY", value);
          } else if (talkingRef.current) {
            const value = (Math.sin(performance.now() / 90) + 1) * 0.28;
            core.setParameterValueById("ParamMouthOpenY", value);
          }
        });

        setStatus("ready");
      } catch (err) {
        console.error("[Live2DStage] gagal init:", err);
        if (!destroyed) {
          setErrorDetail(err?.message || String(err));
          setStatus("error");
        }
      }
    }

    setup();

    return () => {
      destroyed = true;
      removeResize();
      if (modelRef.current) {
        modelRef.current.destroy();
        modelRef.current = null;
      }
      if (appRef.current) {
        appRef.current.destroy(true, { children: true });
        appRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div ref={wrapRef} style={{ position: "relative", width: "100%", height: "100%" }}>
      <canvas ref={canvasRef} style={{ width: "100%", height: "100%", display: "block" }} />
      {status === "loading" && (
        <div style={overlayStyle}>Aiko lagi siap-siap...</div>
      )}
      {status === "error" && (
        <div style={overlayStyle}>
          Gagal load model Aiko.
          {errorDetail && (
            <>
              <br />
              <span style={{ opacity: 0.7, fontSize: "0.78rem" }}>
                {errorDetail}
              </span>
            </>
          )}
        </div>
      )}
    </div>
  );
});

const overlayStyle = {
  position: "absolute",
  inset: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: "var(--text-secondary, #a3a29c)",
  fontFamily: "var(--font-body, sans-serif)",
  fontSize: "0.9rem",
  textAlign: "center",
  padding: "1rem",
};

export default Live2DStage;
