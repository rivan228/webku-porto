"use client";

import { useEffect, useState } from "react";
import styles from "./PageLoader.module.css";

export default function PageLoader() {
  const [visible, setVisible] = useState(true);
  const [hiding, setHiding] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setHiding(true);
      setTimeout(() => setVisible(false), 500);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  if (!visible) return null;

  return (
    <div className={`${styles.loader} ${hiding ? styles.hiding : ""}`}>
      <div className={styles.inner}>
        <div className={styles.logoMark}>
          <i className="fa-solid fa-hexagon-nodes" aria-hidden="true" />
        </div>
        <div className={styles.wordmark}>RIVAN</div>
        <div className={styles.bar}>
          <div className={styles.barFill} />
        </div>
      </div>
    </div>
  );
}
