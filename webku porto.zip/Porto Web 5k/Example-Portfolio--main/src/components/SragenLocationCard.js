"use client";

import React, { useState, useEffect } from "react";
import styles from "./SragenLocationCard.module.css";
import config from "@/lib/config";

export default function SragenLocationCard() {
  const [timeStr, setTimeStr] = useState("");
  const [greeting, setGreeting] = useState("WIB · UTC+7");
  const [copied, setCopied] = useState(false);
  const [mapMode, setMapMode] = useState("interactive");
  const [iframeError, setIframeError] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options = {
        timeZone: "Asia/Jakarta",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      };
      const formatter = new Intl.DateTimeFormat("id-ID", options);
      const time = formatter.format(now);
      setTimeStr(`${time} WIB`);

      const hourFormatter = new Intl.DateTimeFormat("id-ID", {
        timeZone: "Asia/Jakarta",
        hour: "numeric",
        hour12: false,
      });
      const hour = parseInt(hourFormatter.format(now), 10);

      if (hour >= 5 && hour < 11) {
        setGreeting("Pagi di Tulungagung 🌅 · Inovasi & Coding");
      } else if (hour >= 11 && hour < 15) {
        setGreeting("Siang di Tulungagung ☀️ · Development & Bot Rig");
      } else if (hour >= 15 && hour < 18) {
        setGreeting("Sore di Tulungagung 🌇 · Code Review & Testing");
      } else {
        setGreeting("Malam di Tulungagung 🌙 · Deep Focus Coding");
      }
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopyAddress = async () => {
    const fullText = "Tulungagung, Jawa Timur, Indonesia (-8.0658, 111.9034)";
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(fullText);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2400);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2400);
    }
  };

  // Tulungagung Coordinates (-8.0658, 111.9034)
  const staticMapUrl =
    "https://staticmap.openstreetmap.de/staticmap.php?center=-8.0658,111.9034&zoom=13&size=900x350&maptype=mapnik";

  return (
    <div className={styles.locationCard}>
      {/* Card Header */}
      <div className={styles.cardHeader}>
        <div className={styles.statusPill}>
          <span className={styles.radarDot} />
          <span>Home Base Aktif · Tulungagung</span>
        </div>

        {/* View Switcher: Interactive Real Map / Radar Telemetry */}
        <div className={styles.mapSwitchGroup}>
          <button
            type="button"
            onClick={() => setMapMode("radar")}
            className={`${styles.switchBtn} ${mapMode === "radar" ? styles.activeSwitch : ""}`}
            title="Tampilan telemetri radar modern"
          >
            <i className="fa-solid fa-satellite-dish" />
            <span>Radar Telemetri</span>
          </button>
          <button
            type="button"
            onClick={() => setMapMode("interactive")}
            className={`${styles.switchBtn} ${mapMode === "interactive" ? styles.activeSwitch : ""}`}
            title="Tampilkan peta OpenStreetMap Tulungagung"
          >
            <i className="fa-solid fa-map-location-dot" />
            <span>Peta Interaktif</span>
          </button>
        </div>
      </div>

      {/* Map Graphic / Real Map Embed */}
      {mapMode === "interactive" && !iframeError ? (
        <div className={styles.realMapContainer}>
          <img
            src={staticMapUrl}
            alt="Peta lokasi Tulungagung, Jawa Timur"
            className={styles.mapIframe}
            loading="lazy"
            onLoad={() => setIframeError(false)}
            onError={() => setIframeError(true)}
            style={{ objectFit: "cover" }}
          />
          <div className={styles.mapOverlayHeader}>
            <div className={styles.mapBadge}>
              <i className="fa-solid fa-location-dot" style={{ color: "#ef4444" }} />
              <span>Tulungagung, Jawa Timur</span>
            </div>
            <a
              href="https://maps.google.com/?q=Tulungagung,+Jawa+Timur"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.mapDirectLink}
              title="Buka titik koordinat di Google Maps"
            >
              <span>Google Maps</span>
              <i className="fa-solid fa-arrow-up-right-from-square" />
            </a>
          </div>
        </div>
      ) : (
        <div className={styles.radarMap} aria-hidden="true">
          <div className={styles.gridOverlay} />
          <div className={styles.radarRings}>
            <div className={styles.radarRingInner} />
            <div className={styles.sweepArm} />
          </div>
          <div className={styles.centerPin}>
            <div className={styles.pinIcon}>
              <i className="fa-solid fa-location-dot" />
            </div>
            <span className={styles.pinTag}>Tulungagung, JATIM</span>
          </div>
          <span className={styles.coordinateTag}>-8.0658° S, 111.9034° E</span>
        </div>
      )}

      {/* Info Section */}
      <div className={styles.infoSection}>
        <div>
          <div className={styles.cityRow}>
            <h3 className={styles.cityTitle}>
              <span>Kota Tulungagung</span>
              <span className={styles.flagIcon}>🇮🇩</span>
            </h3>
            <span className={styles.regionTag}>Kabupaten Tulungagung</span>
          </div>
          <p className={styles.citySubtitle}>
            Jawa Timur, Indonesia. Hub regional Tulungagung untuk pusat aktivitas coding,
            mobile development (Acode & Termux), dan deployment server bot.
          </p>
        </div>

        {/* Live WIB Clock */}
        <div className={styles.clockBox}>
          <div className={styles.clockLeft}>
            <i className={`fa-regular fa-clock ${styles.clockIcon}`} />
            <span className={styles.timeDigits}>{timeStr || "--:--:-- WIB"}</span>
          </div>
          <span className={styles.timeGreeting}>{greeting}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className={styles.actionRow}>
        <button
          type="button"
          onClick={handleCopyAddress}
          className={`${styles.btnSecondary} ${copied ? styles.copiedBadge : ""}`}
          title="Salin alamat lengkap"
        >
          <i
            className={copied ? "fa-solid fa-check" : "fa-regular fa-copy"}
            aria-hidden="true"
          />
          <span>{copied ? "Alamat Tersalin!" : "Salin Koordinat"}</span>
        </button>

        <a
          href="https://maps.google.com/?q=Tulungagung,+Jawa+Timur"
          target="_blank"
          rel="noopener noreferrer"
          className={styles.btnPrimary}
          title="Buka lokasi asli di Google Maps"
        >
          <i className="fa-solid fa-map-location-dot" aria-hidden="true" />
          <span>Buka di Google Maps</span>
        </a>
      </div>
    </div>
  );
}
