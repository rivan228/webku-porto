"use client";

import { motion } from "framer-motion";
import { useRef } from "react";

const defaultVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.25, 0.1, 0.25, 1],
    },
  },
};

export default function ScrollReveal({
  children,
  variants = defaultVariants,
  className = "",
  delay = 0,
  once = true,
  style = {},
}) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin: "-20px" }}
      variants={{
        ...variants,
        visible: {
          ...variants.visible,
          transition: {
            ...variants.visible.transition,
            delay,
          },
        },
      }}
      className={className}
      style={{ width: "100%", maxWidth: "100%", minWidth: 0, boxSizing: "border-box", ...style }}
    >
      {children}
    </motion.div>
  );
}
