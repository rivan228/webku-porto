import { motion } from "framer-motion";
import styles from "./ProjectCard.module.css";
import { chipColorFor } from "@/lib/chipColor";

export default function ProjectCard({ project, index = 0 }) {
  const num = String(index + 1).padStart(2, "0");

  return (
    <motion.a
      href={project.github}
      target="_blank"
      rel="noopener noreferrer"
      className={styles.card}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
    >
      <div className={styles.topBar}>
        <span className={styles.number}>{num}</span>
        {project.language && project.language !== "Unknown" && (
          <span
            className={styles.languageBox}
            style={{ "--chip-color": chipColorFor(project.language) }}
          >
            {project.language}
          </span>
        )}
      </div>
      <div className={styles.header}>
        <h3 className={styles.title}>{project.title}</h3>
        <span className={styles.arrow}>↗</span>
      </div>
      <p className={styles.description}>{project.description}</p>
      <div className={styles.footer}>
        <div className={styles.tags}>
          {(project.tags || []).map((tag) => (
            <span key={tag} className={styles.tag}>
              {tag}
            </span>
          ))}
        </div>

        {(project.stars > 0 || project.forks > 0) && (
          <div className={styles.stats}>
            {project.stars > 0 && (
              <span>
                <i className="fa-solid fa-star" aria-hidden="true" />
                {project.stars}
              </span>
            )}
            {project.forks > 0 && (
              <span>
                <i className="fa-solid fa-code-branch" aria-hidden="true" />
                {project.forks}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.a>
  );
}
