"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ScrollReveal from "@/components/ScrollReveal";
import PageTransition from "@/components/PageTransition";
import MagneticButton from "@/components/MagneticButton";
import styles from "./page.module.css";
import config from "@/lib/config";

const socials = [
  {
    name: "WhatsApp",
    handle: config.contact.whatsapp.number,
    href: config.contact.whatsapp.href,
    icon: "fa-brands fa-whatsapp",
    desc: "Respons tercepat",
  },
  {
    name: "Telegram",
    handle: `@${config.contact.telegram.username}`,
    href: config.contact.telegram.href,
    icon: "fa-brands fa-telegram",
    desc: "Chat & file transfer",
  },
  {
    name: "GitHub",
    handle: `@${config.contact.github.username}`,
    href: config.contact.github.href,
    icon: "fa-brands fa-github",
    desc: "Repository & open source",
  },
  {
    name: "Saluran WhatsApp",
    handle: "Update & pengumuman",
    href: config.contact.whatsappChannel.href,
    icon: "fa-brands fa-whatsapp",
    desc: "Broadcast channel",
  },
];

const faqs = [
  {
    question: "Apakah Anda menerima pekerjaan freelance?",
    answer:
      "Terbuka untuk kolaborasi skala kecil, terutama seputar bot WhatsApp dan alat otomatisasi. Karena masih pelajar, waktu pengerjaan menyesuaikan jadwal sekolah.",
  },
  {
    question: "Berapa lama biasanya Anda membalas pesan?",
    answer:
      "Biasanya dalam 1x24 jam. Paling cepat melalui WhatsApp atau Telegram.",
  },
  {
    question: "Bahasa pemrograman apa yang Anda kuasai?",
    answer:
      "TypeScript, Next.js, JavaScript, Python, dan PHP. Semua dikerjakan langsung dari ponsel menggunakan Acode dan Termux.",
  },
  {
    question: "Layanan apa saja yang Anda tawarkan?",
    answer:
      "Fokus utama pada pengembangan WhatsApp bot (Baileys), otomatisasi sederhana, dan sedikit penyuntingan video menggunakan Alight Motion.",
  },
  {
    question: "Apakah ada dukungan setelah proyek selesai?",
    answer:
      "Tersedia bantuan dasar untuk perbaikan bug ringan setelah proyek selesai, sesuai kesepakatan di awal.",
  },
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [activeFaq, setActiveFaq] = useState(null);
  const [activeTab, setActiveTab] = useState("info");
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const [status, setStatus] = useState("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const [cooldown, setCooldown] = useState(() => {
    if (typeof window !== "undefined") {
      const lastSent = localStorage.getItem("last_email_sent");
      if (lastSent) {
        const now = Date.now();
        const diff = now - parseInt(lastSent, 10);
        const COOLDOWN_TIME = 60 * 60 * 1000;
        if (diff < COOLDOWN_TIME) {
          return Math.ceil((COOLDOWN_TIME - diff) / 1000);
        }
      }
    }
    return 0;
  });

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setInterval(() => {
        setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [cooldown]);

  const formatCooldown = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (cooldown > 0) {
      setErrorMsg(
        `Mohon tunggu ${formatCooldown(cooldown)} lagi sebelum mengirim pesan berikutnya.`,
      );
      setStatus("error");
      setTimeout(() => setStatus("idle"), 5000);
      return;
    }

    setStatus("sending");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setStatus("success");
        setFormData({ name: "", email: "", message: "" });
        localStorage.setItem("last_email_sent", Date.now().toString());
        setCooldown(60 * 60);
        setTimeout(() => setStatus("idle"), 5000);
      } else {
        setErrorMsg(data.error || "Gagal mengirim pesan.");
        setStatus("error");
        setTimeout(() => setStatus("idle"), 5000);
      }
    } catch (error) {
      console.error("Submit error:", error);
      setErrorMsg("Koneksi bermasalah. Silakan periksa internet Anda.");
      setStatus("error");
      setTimeout(() => setStatus("idle"), 5000);
    }
  };

  return (
    <main className={styles.page}>
      <div className="container">
        <ScrollReveal
          delay={0.1}
          variants={{
            hidden: { opacity: 0, x: 50 },
            visible: {
              opacity: 1,
              x: 0,
              transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] },
            },
          }}
        >
          <div className={styles.header}>
            <p className="section-label">Kontak</p>
            <h1 className="section-title">Mari Terhubung.</h1>
            <p className={styles.metaLine}>
              SALURAN KOMUNIKASI · JALUR LANGSUNG · RESPONS ~24JAM
            </p>
            <div className={styles.statusBadge}>
              <span className={styles.statusDotWrap}>
                <span className={styles.statusDot} />
              </span>
              <span className={styles.statusText}>
                Available for freelance work
              </span>
            </div>
          </div>
        </ScrollReveal>

        <div className={styles.content}>
          <ScrollReveal
            delay={0.3}
            variants={{
              hidden: { opacity: 0, y: 40, skewY: 2 },
              visible: {
                opacity: 1,
                y: 0,
                skewY: 0,
                transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] },
              },
            }}
          >
            <div className={styles.infoSide}>
              <div className={styles.tabHeader}>
                <button
                  className={`${styles.tabBtn} ${activeTab === "info" ? styles.activeTab : ""}`}
                  onClick={() => setActiveTab("info")}
                >
                  Hubungi
                </button>
                <button
                  className={`${styles.tabBtn} ${activeTab === "faq" ? styles.activeTab : ""}`}
                  onClick={() => setActiveTab("faq")}
                >
                  FAQ
                </button>
              </div>

              <div className={styles.tabContent}>
                <AnimatePresence mode="wait">
                  {activeTab === "info" && (
                    <motion.div
                      key="info"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className={styles.text}>
                        <p>
                          Memiliki ide proyek, ingin berkolaborasi, atau sekadar menyapa? Silakan hubungi langsung, saya selalu terbuka untuk berdiskusi seputar pengkodean atau bot WhatsApp.
                        </p>
                      </div>

                      <div className={styles.socialGrid}>
                        {socials.map((social) => (
                          <a
                            key={social.name}
                            href={social.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={styles.socialCard}
                          >
                            <span className={styles.socialIconBox}>
                              <i className={social.icon} />
                            </span>
                            <span className={styles.socialInfo}>
                              <span className={styles.socialName}>{social.name}</span>
                              <span className={styles.socialHandle}>{social.handle}</span>
                            </span>
                            <span className={styles.socialArrow}>
                              <i className="fa-solid fa-arrow-up-right" />
                            </span>
                          </a>
                        ))}
                      </div>

                      <div
                        style={{
                          marginTop: 18,
                          background: "var(--bg-card)",
                          border: "1px solid var(--border)",
                          borderRadius: "var(--radius-lg)",
                          overflow: "hidden",
                          boxShadow: "var(--shadow-soft)",
                        }}
                      >
                        <div
                          style={{
                            padding: "14px 18px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: 12,
                            borderBottom: "1px solid var(--border)",
                            background: "var(--bg-secondary)",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                            <span
                              style={{
                                width: 34,
                                height: 34,
                                borderRadius: "8px",
                                background: "var(--accent-dim)",
                                color: "var(--accent)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: "0.95rem",
                                flexShrink: 0,
                              }}
                            >
                              <i className="fa-solid fa-location-dot" />
                            </span>
                            <div>
                              <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "var(--text-primary)" }}>
                                Tulungagung, Jawa Timur, Indonesia
                              </div>
                              <div style={{ fontSize: "0.72rem", color: "var(--text-tertiary)", fontFamily: "var(--font-mono)" }}>
                                Kabupaten Tulungagung · Jawa Timur · WIB (UTC+7)
                              </div>
                            </div>
                          </div>
                          <a
                            href="https://maps.google.com/?q=Tulungagung,+Jawa+Timur"
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                              fontSize: "0.75rem",
                              fontFamily: "var(--font-body)",
                              fontWeight: 600,
                              color: "var(--accent)",
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 6,
                              padding: "6px 12px",
                              borderRadius: "var(--radius-full)",
                              background: "var(--accent-dim)",
                              border: "1px solid var(--border-hover)",
                              whiteSpace: "nowrap",
                            }}
                          >
                            <span>Google Maps</span>
                            <i className="fa-solid fa-arrow-up-right-from-square" style={{ fontSize: "0.7rem" }} />
                          </a>
                        </div>

                        {/* Real OpenStreetMap Static Map */}
                        <div style={{ position: "relative", width: "100%", height: "180px", background: "var(--bg-secondary)" }}>
                          <img
                            src="https://staticmap.openstreetmap.de/staticmap.php?center=-8.0658,111.9034&zoom=13&size=900x350&maptype=mapnik"
                            alt="Peta lokasi Tulungagung, Jawa Timur"
                            style={{
                              width: "100%",
                              height: "100%",
                              display: "block",
                              objectFit: "cover",
                              filter: "contrast(1.05) saturate(1.1)",
                            }}
                            loading="lazy"
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === "faq" && (
                    <motion.div
                      key="faq"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      transition={{ duration: 0.3 }}
                      className={styles.faqSection}
                    >
                      <h3 className={styles.faqHeader}>Pertanyaan Umum</h3>
                      <div className={styles.faqList}>
                        {faqs.map((faq, index) => (
                          <div
                            key={index}
                            className={`${styles.faqItem} ${activeFaq === index ? styles.active : ""}`}
                          >
                            <button
                              className={styles.faqQuestion}
                              onClick={() =>
                                setActiveFaq(activeFaq === index ? null : index)
                              }
                              type="button"
                            >
                              <span>{faq.question}</span>
                              <span className={styles.faqIcon}>
                                <i
                                  className={
                                    activeFaq === index
                                      ? "fa-solid fa-minus"
                                      : "fa-solid fa-plus"
                                  }
                                />
                              </span>
                            </button>
                            <AnimatePresence initial={false}>
                              {activeFaq === index && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: "auto", opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{
                                    duration: 0.3,
                                    ease: [0.25, 1, 0.5, 1],
                                  }}
                                  style={{ overflow: "hidden" }}
                                >
                                  <div className={styles.faqAnswer}>
                                    <p>{faq.answer}</p>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal
            delay={0.5}
            variants={{
              hidden: { opacity: 0, scale: 0.9, y: 20 },
              visible: {
                opacity: 1,
                scale: 1,
                y: 0,
                transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] },
              },
            }}
          >
            <div className={styles.formSide}>
              <div className={styles.formTerminalHeader}>
                <span className={styles.terminalDots}>
                  <span />
                  <span />
                  <span />
                </span>
                <span className={styles.terminalTitle}>contact.send()</span>
              </div>
              <form className={styles.form} onSubmit={handleSubmit}>
                <div className={styles.inputGroup}>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    placeholder=" "
                    value={formData.name}
                    onChange={handleChange}
                  />
                  <label htmlFor="name">
                    <span className={styles.labelPrefix}>$</span> nama
                  </label>
                </div>

                <div className={styles.inputGroup}>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    placeholder=" "
                    value={formData.email}
                    onChange={handleChange}
                  />
                  <label htmlFor="email">
                    <span className={styles.labelPrefix}>$</span> email
                  </label>
                </div>

                <div className={styles.inputGroup}>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={4}
                    placeholder=" "
                    value={formData.message}
                    onChange={handleChange}
                  ></textarea>
                  <label htmlFor="message">
                    <span className={styles.labelPrefix}>$</span> pesan
                  </label>
                </div>

                <div className={styles.btnWrapper}>
                  <MagneticButton>
                    <button
                      type="submit"
                      disabled={status === "sending" || cooldown > 0}
                      className={`${styles.submitBtn} ${
                        status === "success" ? styles.success : ""
                      } ${cooldown > 0 ? styles.disabled : ""}`}
                    >
                      {status === "idle" && (
                        <>
                          <i className="fa-solid fa-paper-plane" /> Kirim Pesan
                        </>
                      )}
                      {status === "sending" && (
                        <>
                          <i className="fa-solid fa-spinner fa-spin" /> Mengirim...
                        </>
                      )}
                      {status === "success" && (
                        <>
                          <i className="fa-solid fa-check" /> Terkirim!
                        </>
                      )}
                      {status === "error" && (
                        <>
                          <i className="fa-solid fa-triangle-exclamation" /> Gagal! Coba Lagi
                        </>
                      )}
                    </button>
                  </MagneticButton>

                  {status === "error" && errorMsg && (
                    <p className={styles.errorMsg}>{errorMsg}</p>
                  )}

                  {cooldown > 0 && status === "idle" && (
                    <p className={styles.infoMsg}>
                      Anda dapat mengirim pesan kembali dalam {formatCooldown(cooldown)}.
                    </p>
                  )}

                  {status === "success" && (
                    <p className={styles.successMsg}>
                      Terima kasih! Pesan Anda telah diterima, akan dibalas secepatnya.
                    </p>
                  )}
                </div>
              </form>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </main>
  );
}