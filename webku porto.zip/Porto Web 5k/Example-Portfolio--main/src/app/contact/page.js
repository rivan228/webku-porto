import ContactClient from "./ContactClient";

export const metadata = {
  title: "Kontak — Mari Terhubung",
  description: "Hubungi Rivan untuk kolaborasi proyek atau sekadar menyapa.",
};

export default function ContactPage() {
  return <ContactClient />;
}