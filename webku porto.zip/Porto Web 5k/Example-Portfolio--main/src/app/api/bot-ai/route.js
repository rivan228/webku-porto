import { streamUnlimitedAI } from "@/lib/unlimitedai";
import { rateLimit, getClientIdentifier } from "@/lib/rateLimit";
import { GoogleGenAI } from "@google/genai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

const systemPrompt = `Kamu adalah "DevPortfolio AI Bot", asisten AI interaktif dan pintar untuk showcase Developer Portfolio modern.

PROFIL PORTFOLIO & DEVELOPER:
- Persona: Developer Portfolio (DevPortfolio)
- Domisili / Hub: Tulungagung, Jawa Timur
- Rig Coding: Sepenuhnya dikembangkan dan dapat dikelola dari HP Android dan Laptop menggunakan Termux Linux & Acode Editor maupun PC
- WhatsApp Kontak: wa.me/1panns_
- GitHub: github.com/rivan228

FITUR UTAMA WEBSITE PORTFOLIO INI:
1. Website Portfolio Interaktif: Dibangun dengan Next.js 15, App Router, React 19, Tailwind CSS modern glassmorphism.
2. AI Bot Simulator: Simulator bot kecerdasan buatan (Unlimited AI) yang interaktif, responsif, dan siap melayani percakapan bebas, solusi coding, maupun info fitur portfolio secara real-time.
3. Live2D Anime Stage (Aiko): Karakter Live2D interaktif di website yang bisa bergerak, bereaksi terhadap sentuhan, ekspresi mood, dan dilengkapi efek suara (SFX).
4. Full Responsive & Siap Deploy: Siap dideploy ke Vercel atau VPS dengan satu perintah.

GAYA KOMUNIKASI BOT:
- Format ala pesan chat modern: gunakan *tebal* untuk kata kunci, bullet "-" untuk daftar, dan baris baru yang rapi.
- Cerdas, ramah, to the point, dan solutif.
- Selalu jujur sesuai fitur website portfolio, tidak mengada-ada atau melebih-lebihkan hal yang tidak nyata.
- Gunakan Bahasa Indonesia yang ramah, santai, dan profesional.`;

export async function POST(req) {
  try {
    const clientId = getClientIdentifier(req);
    const { success } = await rateLimit(`bot-ai:${clientId}`, 40, 60 * 1000);
    if (!success) {
      return new Response(
        "⚡ *RIvan-MD:* Kecepatan chat terlalu tinggi. Mohon tunggu beberapa detik sebelum mengirim pesan lagi ya!",
        { headers: { "Content-Type": "text/plain; charset=utf-8" } }
      );
    }

    let body;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
    }

    const { messages } = body || {};
    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages array required" }, { status: 400 });
    }

    const sanitizedMessages = messages.slice(-10).map((m) => ({
      role: m.role === "user" ? "user" : "assistant",
      content: String(m.content || "").slice(0, 1500),
    }));

    const apiKey = process.env.GEMINI_API_KEY;

    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        let responded = false;

        try {
          for await (const chunk of streamUnlimitedAI({
            systemPrompt,
            messages: sanitizedMessages,
          })) {
            if (chunk) {
              responded = true;
              controller.enqueue(encoder.encode(chunk));
            }
          }
        } catch (unlimitedErr) {
          console.warn("UnlimitedAI primary failed, attempting fallback:", unlimitedErr?.message);
        }

        if (!responded && apiKey) {
          try {
            const ai = new GoogleGenAI({
              apiKey,
              httpOptions: {
                headers: {
                  "User-Agent": "aistudio-build",
                },
              },
            });

            const contents = [
              { role: "user", parts: [{ text: systemPrompt }] },
              ...sanitizedMessages.map((m) => ({
                role: m.role === "assistant" ? "model" : "user",
                parts: [{ text: m.content }],
              })),
            ];

            const response = await ai.models.generateContentStream({
              model: "gemini-3.8-flash",
              contents,
            });

            for await (const chunk of response) {
              if (chunk.text) {
                responded = true;
                controller.enqueue(encoder.encode(chunk.text));
              }
            }
          } catch (geminiErr) {
            console.error("Gemini fallback error:", geminiErr?.message);
          }
        }

        if (!responded) {
          controller.enqueue(
            encoder.encode(
              "⚡ *NIMZZ-MD BOT (AI)*\n\nMaaf, sistem AI sedang padat sesaat. Silakan coba kirim ulang pertanyaanmu, atau ketik *.menu* untuk opsi lainnya!"
            )
          );
        }

        controller.close();
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (error) {
    console.error("Bot AI API Error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
