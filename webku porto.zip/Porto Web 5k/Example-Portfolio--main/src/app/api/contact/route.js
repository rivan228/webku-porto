import { NextResponse } from "next/server";
import { rateLimit, getClientIdentifier } from "@/lib/rateLimit";

const MAX_NAME_LENGTH = 100;
const MAX_EMAIL_LENGTH = 254; // RFC 5321 max
const MAX_MESSAGE_LENGTH = 4000;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export async function POST(req) {
  try {
    // Reject absurdly large payloads before we even parse JSON.
    const contentLength = Number(req.headers.get("content-length") || 0);
    if (contentLength > 20_000) {
      return NextResponse.json(
        { error: "Request terlalu besar." },
        { status: 413 },
      );
    }

    const clientId = getClientIdentifier(req);
    const { success } = await rateLimit(
      `contact:${clientId}`,
      1,
      60 * 60 * 1000, // 1 request per hour per client
    );

    if (!success) {
      return NextResponse.json(
        {
          error:
            "Terlalu banyak percobaan. Coba lagi dalam beberapa saat.",
        },
        { status: 429 },
      );
    }

    let body;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Body request tidak valid." },
        { status: 400 },
      );
    }

    const { name, email, message } = body || {};

    if (
      typeof name !== "string" ||
      typeof email !== "string" ||
      typeof message !== "string" ||
      !name.trim() ||
      !email.trim() ||
      !message.trim()
    ) {
      return NextResponse.json(
        { error: "Nama, email, dan pesan wajib diisi." },
        { status: 400 },
      );
    }

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedMessage = message.trim();

    if (trimmedName.length > MAX_NAME_LENGTH) {
      return NextResponse.json(
        { error: `Nama maksimal ${MAX_NAME_LENGTH} karakter.` },
        { status: 400 },
      );
    }
    if (trimmedEmail.length > MAX_EMAIL_LENGTH || !EMAIL_REGEX.test(trimmedEmail)) {
      return NextResponse.json(
        { error: "Format email tidak valid." },
        { status: 400 },
      );
    }
    if (trimmedMessage.length > MAX_MESSAGE_LENGTH) {
      return NextResponse.json(
        { error: `Pesan maksimal ${MAX_MESSAGE_LENGTH} karakter.` },
        { status: 400 },
      );
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    if (!botToken || !chatId) {
      console.error("Telegram env vars missing");
      return NextResponse.json(
        { error: "Contact form is not configured yet." },
        { status: 500 },
      );
    }

    const text =
      `<b>Pesan Baru dari Portfolio</b>\n\n` +
      `<b>Nama:</b> ${escapeHtml(trimmedName)}\n` +
      `<b>Email:</b> ${escapeHtml(trimmedEmail)}\n\n` +
      `<b>Pesan:</b>\n${escapeHtml(trimmedMessage)}`;

    const tgResponse = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: "HTML",
        }),
      },
    );

    const tgData = await tgResponse.json().catch(() => ({}));

    if (!tgResponse.ok || !tgData.ok) {
      console.error("Telegram API Error:", tgData);
      return NextResponse.json(
        { error: "Failed to send message. Please try again later." },
        { status: 500 },
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Contact API Server Error:", error);
    return NextResponse.json(
      { error: "Failed to send message. Please try again later." },
      { status: 500 },
    );
  }
}
