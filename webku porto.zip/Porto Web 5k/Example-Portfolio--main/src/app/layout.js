import "./globals.css";
import ClientProviders from "@/components/ClientProviders";
const Analytics = () => null;
import config from "@/lib/config";

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#090a10",
};

export const metadata = {
  metadataBase: new URL(config.siteUrl),
  title: {
    template: "%s",
    default: `${config.name} — Modern Developer Portfolio Showcase`,
  },
  description:
    "Portofolio Modern Developer & WhatsApp Bot Engineer — Pelajar TKJ & Fullstack Bot Engineer.",
  keywords: [
    "developer",
    "portofolio",
    "devportfolio",
    "whatsapp bot",
    "baileys",
    "javascript",
    "typescript",
    "nextjs",
  ],
  authors: [{ name: config.name }],
  creator: config.name,
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/icon.png", type: "image/png", sizes: "32x32" },
      { url: "/icon-192.png", type: "image/png", sizes: "192x192" },
      { url: "/icon-512.png", type: "image/png", sizes: "512x512" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    shortcut: "/favicon.ico",
  },
  openGraph: {
    title: `${config.name} — Modern Developer Portfolio`,
    description:
      "Portofolio Modern Developer & WhatsApp Bot Engineer — Pelajar TKJ & Fullstack Bot Engineer.",
    url: config.siteUrl,
    siteName: `Portofolio ${config.name}`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: `Pratinjau portofolio ${config.name}`,
      },
    ],
    locale: "id_ID",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: `${config.name} — Modern Developer Portfolio`,
    description:
      "Portofolio Modern Developer & WhatsApp Bot Engineer — Pelajar TKJ & Fullstack Bot Engineer.",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

import { Suspense } from "react";
import { getProjects } from "@/lib/github";
import Script from "next/script";

async function ProjectPrefetcher() {
  try {
    await getProjects();
  } catch (e) {}
  return null;
}

export default function RootLayout({ children }) {
  const personJsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: config.fullName,
    alternateName: config.name,
    url: config.siteUrl,
    image: `${config.siteUrl}/og-image.png`,
    jobTitle: "Pelajar & Pengembang WhatsApp Bot",
    description:
      "Developer asal Indonesia dan pelajar SMK jurusan Teknik Komputer dan Jaringan (TKJ), fokus pada pengembangan WhatsApp bot, automasi, dan aplikasi web.",
    nationality: {
      "@type": "Country",
      name: "Indonesia",
    },
    knowsAbout: [
      "Pengembangan WhatsApp Bot",
      "Baileys",
      "Otomatisasi",
      "JavaScript",
      "TypeScript",
      "Python",
      "PHP",
      "Next.js",
      "Pengembangan Web",
    ],
    knowsLanguage: ["id", "en"],
    sameAs: [
      config.contact.github.href,
      config.contact.whatsappChannel.href,
      config.contact.telegram.href,
    ],
  };

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: `Portofolio ${config.name}`,
    url: config.siteUrl,
    description:
      "Portofolio Rivan — pelajar TKJ yang menyukai penyuntingan dan pengembangan WhatsApp bot.",
    inLanguage: "id-ID",
    author: {
      "@type": "Person",
      name: config.fullName,
    },
  };

  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.png" type="image/png" sizes="32x32" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180" />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        />
        <link rel="alternate" type="text/plain" href="/llms.txt" title="LLMs.txt" />
        <script
          id="theme-init"
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var mode=localStorage.getItem("theme-mode");var stored=localStorage.getItem("theme");var t;if(mode==="manual"&&(stored==="light"||stored==="dark")){t=stored;}else{t=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";}document.documentElement.setAttribute("data-theme",t);}catch(e){}})();`,
          }}
        />
      </head>
      <body suppressHydrationWarning>
        <Script
          id="json-ld-person"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(personJsonLd) }}
        />
        <Script
          id="json-ld-website"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
        <ClientProviders>{children}</ClientProviders>
        <Suspense fallback={null}>
          <ProjectPrefetcher />
        </Suspense>
        <Analytics />
      </body>
    </html>
  );
}