"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import ProjectCard from "@/components/ProjectCard";
import ScrollReveal from "@/components/ScrollReveal";
import SectionHeader from "@/components/SectionHeader";
import ProjectSkeleton from "@/components/ProjectSkeleton";

import MagneticButton from "@/components/MagneticButton";
import SragenLocationCard from "@/components/SragenLocationCard";
import projects from "@/lib/data";
import config from "@/lib/config";
import styles from "./page.module.css";
import { getProjects } from "@/lib/github";
import { chipColorFor } from "@/lib/chipColor";

const phrases = [
  "WhatsApp Bot Developer",
  "Full-Stack Web Enthusiast",
  "Open Source Contributor",
  "Automation & Tooling",
];

const stagger = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
  },
};

export default function Home() {
  const [featured, setFeatured] = useState(
    projects.filter((p) => p.featured).slice(0, 3),
  );
  const [typewriterText, setTypewriterText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [wordIndex, setWordIndex] = useState(0);
  const [typingSpeed, setTypingSpeed] = useState(140);
  const [isSelecting, setIsSelecting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const handleTyping = () => {
      const currentWord = phrases[wordIndex];

      if (isSelecting) {
        setTimeout(() => {
          setIsSelecting(false);
          setTypewriterText("");
          setWordIndex((prev) => (prev + 1) % phrases.length);
          setTypingSpeed(140);
        }, 500);
        return;
      }

      if (isDeleting) {
        setTypewriterText((prev) => prev.substring(0, prev.length - 1));
        setTypingSpeed(45);

        if (typewriterText === "") {
          setIsDeleting(false);
          setWordIndex((prev) => (prev + 1) % phrases.length);
          setTypingSpeed(140);
        }
      } else {
        const nextChar = currentWord[typewriterText.length];

        setTypewriterText((prev) => prev + nextChar);
        setTypingSpeed(120);

        if (typewriterText + nextChar === currentWord) {
          setTypingSpeed(2200);
          setIsDeleting(true);
        }
      }
    };

    const timer = setTimeout(handleTyping, typingSpeed);
    return () => clearTimeout(timer);
  }, [typewriterText, isDeleting, wordIndex, typingSpeed, isSelecting]);

  const terminalLines = [
    { cmd: "whoami", out: `${config.name} — ${config.status}` },
    { cmd: "location", out: config.location },
    { cmd: "stack --primary", out: config.languages.slice(0, 4), isChips: true },
    { cmd: "status", out: "ready for new projects 🚀" },
  ];

  useEffect(() => {
    async function fetchFeatured() {
      try {
        const cached = sessionStorage.getItem("featured_repos");
        if (cached) {
          setFeatured(JSON.parse(cached).slice(0, 3));
          setIsLoading(false);
          return;
        }

        const mapped = await getProjects();
        if (mapped.length === 0) {
          setIsLoading(false);
          return;
        }

        const top3 = mapped.slice(0, 3);
        setFeatured(top3);
        sessionStorage.setItem("featured_repos", JSON.stringify(top3));
      } catch (err) {
      } finally {
        setIsLoading(false);
      }
    }
    fetchFeatured();
  }, []);

  return (
    <main>
      <section className={styles.hero}>
        <div className={styles.heroGlowTop} aria-hidden="true" />
        <div className={styles.heroGlowRight} aria-hidden="true" />
        <div className="container" style={{ position: "relative", zIndex: 1 }}>
          <div className={styles.heroLayout}>
            <motion.div
              className={styles.content}
              variants={stagger}
              initial="hidden"
              animate="visible"
            >
              <motion.div variants={fadeUp}>
                <Link href="/about" className={styles.heroBadge} style={{ textDecoration: "none" }}>
                  <span className={styles.badgePulse} />
                  <span>Tersedia untuk Proyek & Kolaborasi</span>
                  <span className={styles.badgeArrow}>→</span>
                </Link>
              </motion.div>

              <motion.h1 className={styles.title} variants={fadeUp}>
                Halo, saya <span className={styles.titleAccent}>{config.name}</span>
              </motion.h1>

              <motion.h2 className={styles.titleSub} variants={fadeUp}>
                <span className={isSelecting ? styles.selecting : ""}>
                  {typewriterText}
                </span>
                <span className={styles.cursor}>|</span>
              </motion.h2>

              <motion.p className={styles.subtitle} variants={fadeUp}>
                {config.tagline}
              </motion.p>

              <motion.div className={styles.ctas} variants={fadeUp}>
                <MagneticButton>
                  <Link href="/projects" className={styles.ctaPrimary}>
                    <span>Lihat Proyek</span>
                    <i className="fa-solid fa-arrow-right" aria-hidden="true" />
                  </Link>
                </MagneticButton>
                <MagneticButton>
                  <Link href="/bot" className={styles.ctaSecondary}>
                    <i className="fa-brands fa-whatsapp" />
                    <span>Bot Simulator</span>
                  </Link>
                </MagneticButton>
                <MagneticButton>
                  <Link href="/contact" className={styles.ctaSecondary}>
                    <span>Hubungi Saya</span>
                  </Link>
                </MagneticButton>
                <a
                  href={config.contact.github.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.ctaGithub}
                  aria-label="GitHub RivanAI"
                >
                  <i className="fa-brands fa-github" aria-hidden="true" />
                  <span>GitHub</span>
                </a>
              </motion.div>
            </motion.div>

            <motion.div
              className={styles.heroVisual}
              initial={{ opacity: 0, y: 20, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                delay: 0.3,
                duration: 0.7,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <div className={styles.terminal}>
                <div className={styles.terminalBar}>
                  <span className={styles.dot} data-c="red" />
                  <span className={styles.dot} data-c="yellow" />
                  <span className={styles.dot} data-c="green" />
                  <span className={styles.terminalTitle}>
                    {config.name.toLowerCase()}@workspace:~
                  </span>
                </div>
                <div className={styles.terminalBody}>
                  {terminalLines.map((line, i) => (
                    <div key={line.cmd} className={styles.terminalLine}>
                      <p className={styles.terminalCmd}>
                        <span className={styles.terminalPrompt}>$</span>{" "}
                        {line.cmd}
                      </p>
                      {line.isChips ? (
                        <p className={styles.terminalChips}>
                          {line.out.map((lang) => (
                            <span
                              key={lang}
                              className={styles.terminalChip}
                              style={{ "--chip-color": chipColorFor(lang) }}
                            >
                              {lang}
                            </span>
                          ))}
                        </p>
                      ) : (
                        <p className={styles.terminalOut}>
                          &gt; {line.out}
                          {i === terminalLines.length - 1 && (
                            <span className={styles.cursor}>|</span>
                          )}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        <motion.div
          className={styles.scrollIndicator}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <span>GULIR KE BAWAH</span>
          <div className={styles.chevron} />
        </motion.div>
      </section>

      <section className={styles.featured}>
        <div className="container">
          <ScrollReveal>
            <SectionHeader
              label="Karya Pilihan"
              title="Proyek Unggulan"
              meta="DATA REAL-TIME GITHUB · TERBARU & TERPOPULER"
              className={styles.featuredHeader}
            >
              <Link href="/projects" className={styles.viewAll}>
                <span>Semua Proyek</span>
                <i className="fa-solid fa-arrow-right" aria-hidden="true" />
              </Link>
            </SectionHeader>
          </ScrollReveal>

          <div className={styles.grid}>
            {isLoading
              ? Array.from({ length: 3 }).map((_, i) => (
                  <ProjectSkeleton key={i} />
                ))
              : featured.map((project, i) => (
                  <ScrollReveal key={project.id || project.title} delay={i * 0.1}>
                    <ProjectCard
                      project={{
                        ...project,
                        tags: (project.tags || []).slice(0, 3),
                      }}
                      index={i}
                    />
                  </ScrollReveal>
                ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "0 0 60px 0" }}>
        <div className="container">
          <ScrollReveal>
            <div style={{ maxWidth: "860px", margin: "0 auto" }}>
              <div style={{ marginBottom: "20px", textAlign: "center" }}>
                <span className="section-label">Real-Time Telemetry & Location</span>
                <h2 style={{ fontSize: "1.8rem", fontWeight: 800, color: "var(--text-primary)", letterSpacing: "-0.02em", margin: "8px 0" }}>
                  Pusat Operasional Tulungagung, Jawa Timur
                </h2>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", maxWidth: "560px", margin: "0 auto" }}>
                  Hub regional Tulungagung untuk riset dan pengembangan bot. Dilengkapi telemetri radar aktif serta tautan peta presisi.
                </p>
              </div>
              <SragenLocationCard />
            </div>
          </ScrollReveal>
        </div>
      </section>
    </main>
  );
}
