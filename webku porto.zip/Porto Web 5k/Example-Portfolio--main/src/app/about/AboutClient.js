"use client";

import React, { useState } from "react";
import Link from "next/link";
import PageTransition from "@/components/PageTransition";
import ScrollReveal from "@/components/ScrollReveal";
import SragenLocationCard from "@/components/SragenLocationCard";
import LiveStatusCard from "@/components/LiveStatusCard";
import GithubActivity from "@/components/GithubActivity";
import BotSimulator from "@/components/BotSimulator";
import config from "@/lib/config";
import styles from "./page.module.css";

const rigTools = [
  {
    name: "Acode Editor",
    tag: "Mobile Monaco IDE",
    desc: "Code editor berbasis Monaco engine di Android. Dilengkapi GitHub integration, syntax highlight, dan instant preview.",
    icon: "/apps/acode.png",
    isImg: true,
  },
  {
    name: "Termux Linux",
    tag: "Android Subsystem",
    desc: "Terminal Linux penuh di smartphone. Menjalankan Node.js LTS, Git CLI, compiler, dan server bot WhatsApp 24/7.",
    icon: "fa-solid fa-terminal",
    isImg: false,
  },
  {
    name: "Baileys MD",
    tag: "WhatsApp Web Socket",
    desc: "Arsitektur multi-device WhatsApp tanpa browser headless (Puppeteer/Chromium), sangat hemat RAM & baterai ponsel.",
    icon: "fa-brands fa-whatsapp",
    isImg: false,
  },
  {
    name: "Alight Motion",
    tag: "VFX & Motion Design",
    desc: "Aplikasi motion graphic tingkat lanjut di mobile untuk keyframe animation, transisi tipografi, dan komposisi video.",
    icon: "/apps/alight-motion.png",
    isImg: true,
  },
];

const techStack = [
  {
    name: "TypeScript",
    category: "Bahasa",
    desc: "Type safety untuk skala bot besar dan arsitektur modular Baileys.",
    icon: "fa-brands fa-js",
  },
  {
    name: "JavaScript (ESM)",
    category: "Bahasa",
    desc: "Bahasa utama untuk event loop, plugin handler, dan automasi.",
    icon: "fa-brands fa-square-js",
  },
  {
    name: "Python",
    category: "Bahasa",
    desc: "Scripting praktis, web scraper, dan utilitas data cepat di Termux.",
    icon: "fa-brands fa-python",
  },
  {
    name: "PHP",
    category: "Bahasa",
    desc: "Pemrosesan backend web dan integrasi API sederhana.",
    icon: "fa-brands fa-php",
  },
  {
    name: "Next.js",
    category: "Web & Frontend",
    desc: "React framework modern dengan App Router, SSR, dan integrasi API.",
    icon: "fa-solid fa-cube",
  },
  {
    name: "React.js",
    category: "Web & Frontend",
    desc: "Pembangunan antarmuka reaktif dan komponen modular.",
    icon: "fa-brands fa-react",
  },
  {
    name: "Tailwind CSS",
    category: "Web & Frontend",
    desc: "Utility-first styling untuk desain cepat, konsisten, dan responsif.",
    icon: "fa-solid fa-wind",
  },
  {
    name: "Baileys WhatsApp",
    category: "Bot & Automasi",
    desc: "Library socket WhatsApp Web Multi-Device tanpa browser Puppeteer.",
    icon: "fa-brands fa-whatsapp",
  },
  {
    name: "Node.js",
    category: "Bot & Automasi",
    desc: "Runtime JavaScript server-side untuk menjalankan listener bot.",
    icon: "fa-brands fa-node-js",
  },
  {
    name: "Termux Linux",
    category: "Database & Tools",
    desc: "Lingkungan terminal Linux di smartphone Android untuk dev rig.",
    icon: "fa-solid fa-terminal",
  },
  {
    name: "Git & GitHub",
    category: "Database & Tools",
    desc: "Version control untuk melacak commit, branch, dan repositori terbuka.",
    icon: "fa-brands fa-github",
  },
  {
    name: "SQLite & MongoDB",
    category: "Database & Tools",
    desc: "Penyimpanan database lokal & NoSQL untuk state pengguna bot.",
    icon: "fa-solid fa-database",
  },
];

const timelineMilestones = [
  {
    period: "2026 — SEKARANG",
    role: "Pelajar Jurusan Teknik Komputer & Jaringan (TKJ)",
    org: "SMK di Tulungagung, Jawa Timur",
    desc: "Mempelajari administrasi infrastruktur jaringan komputer, routing Mikrotik, konfigurasi Linux Server, keamanan jaringan, dan manajemen konektivitas fiber optik sambil terus mengembangkan portofolio bot dan web.",
  },
  {
    period: "2025 — 2026",
    role: "WhatsApp Bot Architect & Script Automator",
    org: "Open Source & Proyek Mandiri",
    desc: "Merancang bot WhatsApp multi-device modular berbasis Baileys dan TypeScript. Mengembangkan plugin dinamis, downloader media, integrasi AI, dan sistem auto-responder yang seluruhnya di-coding langsung dari smartphone via Acode & Termux.",
  },
  {
    period: "2023 — 2025",
    role: "Penjual Akun Game & Digital",
    org: "Usaha Mandiri",
    desc: "Mengelola jual-beli akun game, mulai dari membuat listing yang jelas hingga melayani pertanyaan pelanggan dan memastikan proses transaksi berjalan dengan baik.",
  },
];

export default function AboutClient() {
  const [activeTab, setActiveTab] = useState("simulator");
  const [selectedTechCat, setSelectedTechCat] = useState("Semua");
  const [termuxCopied, setTermuxCopied] = useState(false);

  const copyTermuxCmd = () => {
    navigator.clipboard.writeText("pkg update && pkg install nodejs-lts git python -y");
    setTermuxCopied(true);
    setTimeout(() => setTermuxCopied(false), 2000);
  };

  const filteredTech =
    selectedTechCat === "Semua"
      ? techStack
      : techStack.filter((t) => t.category === selectedTechCat);

  const avatarSrc = config.profile?.avatarUrl || config.avatar;
  const bannerSrc = config.profile?.bannerUrl;
  const isBannerVideo =
    bannerSrc && /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(bannerSrc);

  return (
    <PageTransition>
      <main className={styles.pageWrapper}>
        <div className={styles.container}>
          <ScrollReveal>
            <div className={styles.heroCard}>
              <div className={styles.heroBanner}>
                {bannerSrc && isBannerVideo ? (
                  <video
                    className={styles.bannerVideo}
                    src={bannerSrc}
                    autoPlay
                    loop
                    muted
                    playsInline
                  />
                ) : bannerSrc ? (
                  <img src={bannerSrc} alt="Banner" className={styles.bannerImg} />
                ) : (
                  <div className={styles.bannerOverlay} />
                )}
                <div className={styles.bannerGlow} />
              </div>

              <div className={styles.heroContent}>
                <div className={styles.avatarWrapper}>
                  <div className={styles.avatarBorder}>
                    <img
                      src={avatarSrc}
                      alt={config.fullName || config.name}
                      className={styles.avatarImg}
                    />
                  </div>
                  <span className={styles.onlinePulse} title="Online & Aktif" />
                </div>

                <div className={styles.heroHeaderRow}>
                  <div className={styles.heroIdentity}>
                    <div className={styles.nameRow}>
                      <h1 className={styles.mainName}>
                        {config.fullName || "Muhammad Bagus Rivan Saputra"}
                      </h1>
                      <span className={styles.handleBadge}>@{config.name.toLowerCase()}</span>
                    </div>

                    <div className={styles.metaLine}>
                      <span>{config.age} Tahun</span>
                      <span className={styles.metaDot} aria-hidden="true">·</span>
                      <span className={styles.metaHighlight}>{config.status}</span>
                      <span className={styles.metaDot} aria-hidden="true">·</span>
                      <span>Tulungagung, Jawa Timur</span>
                      <span className={styles.metaDot} aria-hidden="true">·</span>
                      <span className={styles.metaHighlight}>WhatsApp Bot Dev & Services</span>
                    </div>
                  </div>

                  <div className={styles.heroActions}>
                    <a
                      href={config.contact.whatsapp.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={styles.primaryBtn}
                    >
                      <i className="fa-brands fa-whatsapp" />
                      <span>Chat WhatsApp</span>
                    </a>
                    <Link href="/bot" className={styles.secondaryBtn}>
                      <i className="fa-solid fa-robot" />
                      <span>Coba Bot Simulator</span>
                    </Link>
                  </div>
                </div>

                <p className={styles.bioText}>
                  Halo! Selamat datang di <strong>DevPortfolio</strong>, template portofolio developer modern
                  untuk showcase keahlian <strong>Teknik Komputer & Jaringan (TKJ)</strong> dan Fullstack Development
                  yang berlokasi di <strong>Tulungagung, Jawa Timur</strong>. Berfokus pada
                  rekayasa bot WhatsApp modern menggunakan arsitektur Baileys Multi-Device, automasi alur kerja,
                  serta penyediaan solusi website dan bot siap pakai.
                </p>
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.08}>
            <div className={styles.highlightsGrid}>
              <div className={styles.highlightCard}>
                <div className={styles.highlightIcon}>
                  <i className="fa-solid fa-location-dot" />
                </div>
                <div className={styles.highlightInfo}>
                  <span className={styles.highlightLabel}>01. Domisili</span>
                  <span className={styles.highlightTitle}>Tulungagung, Jawa Timur</span>
                  <span className={styles.highlightDesc}>Kabupaten Tulungagung</span>
                </div>
              </div>

              <div className={styles.highlightCard}>
                <div className={styles.highlightIcon}>
                  <i className="fa-solid fa-graduation-cap" />
                </div>
                <div className={styles.highlightInfo}>
                  <span className={styles.highlightLabel}>02. Pendidikan</span>
                  <span className={styles.highlightTitle}>SMK Jurusan TKJ</span>
                  <span className={styles.highlightDesc}>Jaringan, Server & Coding</span>
                </div>
              </div>

              <div className={styles.highlightCard}>
                <div className={styles.highlightIcon}>
                  <i className="fa-solid fa-robot" />
                </div>
                <div className={styles.highlightInfo}>
                  <span className={styles.highlightLabel}>03. Spesialisasi</span>
                  <span className={styles.highlightTitle}>WhatsApp Bot Dev</span>
                  <span className={styles.highlightDesc}>Baileys MD & TypeScript</span>
                </div>
              </div>

              <div className={styles.highlightCard}>
                <div className={styles.highlightIcon}>
                  <i className="fa-solid fa-mobile-screen-button" />
                </div>
                <div className={styles.highlightInfo}>
                  <span className={styles.highlightLabel}>04. Metode Pengembangan</span>
                  <span className={styles.highlightTitle}>Vibe Coding</span>
                  <span className={styles.highlightDesc}>Mengembangkan ide aplikasi dengan bantuan AI, lalu meninjau, menguji, dan menyempurnakan kode secara bertahap.</span>
                </div>
              </div>
            </div>
          </ScrollReveal>

          <div className={styles.tabsContainer}>
            <div className={styles.tabsScroller}>
              <button
                type="button"
                onClick={() => setActiveTab("simulator")}
                className={`${styles.tabBtn} ${activeTab === "simulator" ? styles.activeTabBtn : ""}`}
              >
                <i className="fa-solid fa-robot" />
                <span>AI Bot Simulator</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("rig")}
                className={`${styles.tabBtn} ${activeTab === "rig" ? styles.activeTabBtn : ""}`}
              >
                <i className="fa-solid fa-mobile-screen" />
                <span>Mobile Rig & Lab</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("tech")}
                className={`${styles.tabBtn} ${activeTab === "tech" ? styles.activeTabBtn : ""}`}
              >
                <i className="fa-solid fa-layer-group" />
                <span>Tech Stack Matrix</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("github")}
                className={`${styles.tabBtn} ${activeTab === "github" ? styles.activeTabBtn : ""}`}
              >
                <i className="fa-brands fa-github" />
                <span>GitHub & Aktivitas</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("journey")}
                className={`${styles.tabBtn} ${activeTab === "journey" ? styles.activeTabBtn : ""}`}
              >
                <i className="fa-solid fa-timeline" />
                <span>Perjalanan & Studi</span>
              </button>
            </div>
          </div>

          {activeTab === "simulator" && (
            <div style={{ width: "100%", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: "16px" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                <h3 className={styles.ctaTitle}>Uji Coba Langsung di AI Bot Simulator (Unlimited AI)</h3>
                <p className={styles.bioText}>
                  Uji coba interaksi nyata dengan bot kecerdasan buatan interaktif yang terkoneksi langsung ke Unlimited Chat AI. Ketik pesan bebas, tanya coding, atau ketik <code>.menu</code> / <code>.status</code>:
                </p>
              </div>
              <BotSimulator />
            </div>
          )}

          {activeTab === "rig" && (
            <div className={styles.labGrid}>
              <div className={styles.leftColumn}>
                <div className={styles.rigToolsCard}>
                  <div className={styles.cardHeader}>
                    <h3 className={styles.cardTitle}>
                      <i className="fa-solid fa-microchip" />
                      <span>Alur Mobile Development Rig</span>
                    </h3>
                    <span className={styles.cardBadge}>Full Smartphone Setup</span>
                  </div>

                  <p className={styles.bioText}>
                    Keunikan utama alur kerja saya adalah coding, testing socket, kompilasi TypeScript,
                    hingga deployment bot dijalankan langsung dari smartphone Android tanpa laptop utama:
                  </p>

                  <div className={styles.toolsGrid}>
                    {rigTools.map((tool) => (
                      <div key={tool.name} className={styles.toolItem}>
                        <div className={styles.toolHeader}>
                          <div className={styles.toolIcon}>
                            {tool.isImg ? (
                              <img src={tool.icon} alt={tool.name} />
                            ) : (
                              <i className={tool.icon} />
                            )}
                          </div>
                          <div>
                            <h4 className={styles.toolName}>{tool.name}</h4>
                            <span className={styles.toolTag}>{tool.tag}</span>
                          </div>
                        </div>
                        <p className={styles.toolDesc}>{tool.desc}</p>
                      </div>
                    ))}
                  </div>

                  <div className={styles.terminalCard}>
                    <div className={styles.terminalTop}>
                      <div className={styles.terminalDots}>
                        <span className={styles.terminalDot} />
                        <span className={styles.terminalDot} />
                        <span className={styles.terminalDot} />
                      </div>
                      <span className={styles.terminalTitle}>termux-setup.sh</span>
                      <button
                        type="button"
                        onClick={copyTermuxCmd}
                        className={styles.copyTermBtn}
                        title="Salin Perintah Setup"
                      >
                        <i
                          className={
                            termuxCopied ? "fa-solid fa-check" : "fa-regular fa-copy"
                          }
                        />
                        <span>{termuxCopied ? "Tersalin!" : "Salin"}</span>
                      </button>
                    </div>
                    <div className={styles.terminalBody}>
                      <span className={styles.termPrompt}>$</span>
                      <span>pkg update && pkg install nodejs-lts git python -y</span>
                    </div>
                  </div>
                </div>

                <SragenLocationCard />
              </div>

              <div className={styles.rightColumn}>
                <LiveStatusCard />

                <div className={styles.rigToolsCard}>
                  <div className={styles.cardHeader}>
                    <h3 className={styles.cardTitle}>
                      <i className="fa-brands fa-whatsapp" />
                      <span>Ekosistem WhatsApp Bot</span>
                    </h3>
                  </div>
                  <p className={styles.bioText}>
                    Bot dibangun dengan arsitektur event-driven berbasis Baileys.
                    Mendukung multi-device session, auto-pairing code (tanpa perlu scan QR fisik),
                    plugin modular hot-reload, dan integrasi API AI.
                  </p>
                  <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "4px" }}>
                    <a
                      href={config.contact.whatsappChannel?.href || "#"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={styles.secondaryBtn}
                      style={{ fontSize: "0.8rem", padding: "8px 14px" }}
                    >
                      <i className="fa-brands fa-whatsapp" />
                      <span>Saluran WhatsApp Kami</span>
                    </a>
                    <Link
                      href="/bot"
                      className={styles.primaryBtn}
                      style={{ fontSize: "0.8rem", padding: "8px 14px" }}
                    >
                      <i className="fa-solid fa-robot" />
                      <span>Coba Bot Simulator AI</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "tech" && (
            <div className={styles.techMatrixWrapper}>
              <div className={styles.cardHeader}>
                <div>
                  <h3 className={styles.cardTitle}>
                    <i className="fa-solid fa-layer-group" />
                    <span>Matriks Teknologi & Keahlian</span>
                  </h3>
                  <p className={styles.bioText} style={{ marginTop: "4px" }}>
                    Perangkat lunak, bahasa pemrograman, dan ekosistem yang aktif digunakan untuk
                    membangun bot WhatsApp dan aplikasi web komersial.
                  </p>
                </div>
              </div>

              <div className={styles.filterRow}>
                {["Semua", "Bahasa", "Web & Frontend", "Bot & Automasi", "Database & Tools"].map(
                  (cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedTechCat(cat)}
                      className={`${styles.filterBtn} ${
                        selectedTechCat === cat ? styles.activeFilterBtn : ""
                      }`}
                    >
                      {cat}
                    </button>
                  ),
                )}
              </div>

              <div className={styles.techGrid}>
                {filteredTech.map((item) => (
                  <div key={item.name} className={styles.techCard}>
                    <div className={styles.techIconBox}>
                      <i className={item.icon} />
                    </div>
                    <div className={styles.techMeta}>
                      <div className={styles.techTop}>
                        <span className={styles.techName}>{item.name}</span>
                        <span className={styles.techCat}>{item.category}</span>
                      </div>
                      <p className={styles.techDesc}>{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "github" && (
            <div>
              <GithubActivity username={config.contact.github.username} />
            </div>
          )}

          {activeTab === "journey" && (
            <div className={styles.timelineWrapper}>
              <div className={styles.cardHeader}>
                <h3 className={styles.cardTitle}>
                  <i className="fa-solid fa-graduation-cap" />
                  <span>Jejak Langkah & Perjalanan</span>
                </h3>
                <span className={styles.cardBadge}>Evolusi Skill</span>
              </div>

              <div className={styles.timelineList}>
                {timelineMilestones.map((m, idx) => (
                  <div key={idx} className={styles.timelineItem}>
                    <span className={styles.timelineDot} />
                    <span className={styles.timelinePeriod}>{m.period}</span>
                    <h4 className={styles.timelineRole}>{m.role}</h4>
                    <span className={styles.timelineOrg}>{m.org}</span>
                    <p className={styles.timelineDesc}>{m.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <ScrollReveal delay={0.12}>
            <div className={styles.ctaCard}>
              <div className={styles.ctaText}>
                <h3 className={styles.ctaTitle}>
                  Tertarik Berkolaborasi atau Diskusi Proyek?
                </h3>
                <p className={styles.ctaSubtitle}>
                  Terbuka untuk kolaborasi pembuatan web app modern, integrasi bot interaktif, atau konsultasi ide teknologi.
                </p>
              </div>

              <div className={styles.ctaButtons}>
                <a
                  href={config.contact.whatsapp.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.waBtn}
                >
                  <i className="fa-brands fa-whatsapp" />
                  <span>Hubungi WhatsApp</span>
                </a>
                <Link href="/contact" className={styles.tgBtn}>
                  <i className="fa-solid fa-paper-plane" />
                  <span>Kirim Pesan</span>
                </Link>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </main>
    </PageTransition>
  );
}
