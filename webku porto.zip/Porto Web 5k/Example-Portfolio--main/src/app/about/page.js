import AboutClient from "./AboutClient";

export const metadata = {
  title: "About — DevPortfolio",
  description:
    "Profil DevPortfolio, pelajar SMK jurusan Teknik Komputer dan Jaringan (TKJ) dari Tulungagung, Jawa Timur. Fokus pada pengembangan bot WhatsApp, web development, dan full-stack development.",
};

export default function AboutPage() {
  return <AboutClient />;
}
