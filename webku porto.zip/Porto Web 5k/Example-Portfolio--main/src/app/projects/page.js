import { Suspense } from "react";
import ProjectList from "@/components/ProjectList";
import fallbackProjects from "@/lib/data";
import { getProjects } from "@/lib/github";
import config from "@/lib/config";
import Script from "next/script";
import Loading from "./loading";

export const metadata = {
  title: "Proyek — Karya yang Pernah Dibuat",
  description:
    "Kumpulan proyek open-source Rivan: WhatsApp bot, aplikasi web Next.js, dan tools automasi. Data diambil real-time langsung dari GitHub.",
};

export const revalidate = 60;

async function ProjectData() {
  const githubProjects = await getProjects();
  const projects =
    githubProjects.length > 0 ? githubProjects : fallbackProjects;

  // Structured data mirrors exactly what's rendered, ordered by most
  // recently pushed first — keeps AI/search crawlers in sync with the
  // real, current state of the projects instead of stale cached copies.
  const itemListJsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Proyek Rivan",
    itemListOrder: "https://schema.org/ItemListOrderDescending",
    numberOfItems: projects.length,
    itemListElement: projects.slice(0, 20).map((p, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: p.title,
      description: p.description || undefined,
      url: p.github || `${config.siteUrl}/projects`,
    })),
  };

  return (
    <>
      <Script
        id="json-ld-projects"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListJsonLd) }}
      />
      <ProjectList projects={projects} />
    </>
  );
}

export default function Projects() {
  return (
    <Suspense fallback={<Loading />}>
      <ProjectData />
    </Suspense>
  );
}
