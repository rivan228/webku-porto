"use client";

import React from "react";
import PageTransition from "@/components/PageTransition";
import ScrollReveal from "@/components/ScrollReveal";
import BotSimulator from "@/components/BotSimulator";
import styles from "./page.module.css";

const specs = [
  {
    icon: "fa-solid fa-microchip",
    label: "AI Processing",
    value: "Unlimited AI Streaming Engine",
  },
  {
    icon: "fa-solid fa-bolt",
    label: "Response Latency",
    value: "< 35ms Streaming Time",
  },
  {
    icon: "fa-solid fa-layer-group",
    label: "Web Architecture",
    value: "Next.js 15 + Edge Routing",
  },
  {
    icon: "fa-solid fa-mobile-screen",
    label: "Dev Environment",
    value: "Mobile Rig (Acode + Termux)",
  },
];

export default function BotClient() {
  return (
    <PageTransition>
      <main className={styles.wrapper}>
        <div className={styles.container}>
          <ScrollReveal>
            <div className={styles.heroHeader}>
              <div className={styles.badge}>
                <i className="fa-solid fa-robot" />
                <span>AI Bot Simulator + Unlimited Intelligence</span>
              </div>
              <h1 className={styles.pageTitle}>
                Simulator Bot AI &{" "}
                <span className={styles.titleGradient}>Unlimited Chat Assistant</span>
              </h1>
              <p className={styles.pageDesc}>
                Uji coba langsung AI Bot Simulator interaktif modern.
                Dibangun dengan engine streaming tanpa batas kuota, responsif, dan siap melayani
                tanya jawab coding, eksplorasi teknologi, maupun simulasi perintah bot interaktif.
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.1}>
            <div className={styles.simulatorSection}>
              <BotSimulator />

              <div className={styles.specRow}>
                {specs.map((s) => (
                  <div key={s.label} className={styles.specCard}>
                    <div className={styles.specIcon}>
                      <i className={s.icon} />
                    </div>
                    <div className={styles.specInfo}>
                      <span className={styles.specLabel}>{s.label}</span>
                      <span className={styles.specValue}>{s.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
      </main>
    </PageTransition>
  );
}
