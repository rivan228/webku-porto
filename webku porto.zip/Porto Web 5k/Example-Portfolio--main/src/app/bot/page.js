import BotClient from "./BotClient";

export const metadata = {
  title: "AI Bot Simulator (Unlimited AI) — DevPortfolio",
  description:
    "Uji coba AI Bot Simulator interaktif yang terhubung langsung ke Unlimited Chat AI. Coba interaksi cerdas secara real-time.",
  openGraph: {
    title: "AI Bot Simulator (Unlimited AI) — DevPortfolio",
    description:
      "Uji coba AI Bot Simulator interaktif yang terhubung langsung ke Unlimited Chat AI.",
  },
};

export default function BotPage() {
  return <BotClient />;
}
