<div align="center">

# Rivan Portfolio — v2

Portofolio pribadi **Muhamad Bagus Rivan Saputra (Rivan)** — pelajar TKJ, developer WhatsApp bot & aplikasi web.
Dibangun dengan Next.js App Router, dilengkapi AI assistant kontekstual, dan dirancang untuk mudah dikenali oleh search engine maupun AI assistant (Google AI Overview, ChatGPT, Gemini, Perplexity, dll).

<p>
  <img src="https://img.shields.io/badge/Next.js-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js">
  <img src="https://img.shields.io/badge/React-149ECA?style=for-the-badge&logo=react&logoColor=white" alt="React">
  <img src="https://img.shields.io/badge/Vanilla_CSS-1572B6?style=for-the-badge&logo=css3&logoColor=white" alt="CSS3">
  <img src="https://img.shields.io/badge/Framer_Motion-black?style=for-the-badge&logo=framer&logoColor=F0F" alt="Framer Motion">
  <img src="https://img.shields.io/badge/Vercel-000000?style=for-the-badge&logo=vercel&logoColor=white" alt="Vercel">
  <img src="https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge" alt="MIT License">
</p>

**Live:** [nimzz.web.id](https://nimzz.web.id)

</div>

---

## Tentang v2

Ini adalah upgrade besar dari versi sebelumnya. Perubahan utama:

| Area | Sebelumnya | v2 |
|---|---|---|
| Tema | Dark mode saja | **Dark & Light mode**, otomatis mengikuti preferensi sistem device, bisa di-toggle manual dan diingat |
| Ikon | Campuran SVG custom | **Font Awesome** untuk semua ikon UI; brand logo tetap SVG asli hanya jika tidak tersedia resmi di Font Awesome |
| Halaman Pastebin | Ada | **Dihapus** — tidak lagi dibutuhkan |
| AI Assistant | Kadang menjawab data GitHub basi/lama | **Diperbaiki total** — data proyek diambil terurut berdasar waktu push terbaru (bukan popularitas), cache dipersingkat jadi 60 detik, dan system prompt AI ditegaskan wajib pakai data real-time |
| Keamanan | Rate limit in-memory yang rapuh, `.env` berpotensi bocor, sistem admin tak terpakai | **Diperkuat** — rate limiting berbasis Redis, security headers lengkap (CSP/HSTS/dll), validasi input ketat, `.gitignore` proper, sistem admin yang tak terpakai dihapus |
| SEO / AI Discovery | Minim | `robots.txt`, `sitemap.xml`, **`llms.txt`**, dan structured data (JSON-LD) yang jauh lebih lengkap |
| Lisensi | Tidak ada | **MIT** — siap open source |

---

## Fitur Utama

### 🌗 Dark & Light Mode
Tema mengikuti `prefers-color-scheme` perangkat secara default dan langsung menyesuaikan bila tema sistem berubah saat halaman masih terbuka. Sekali user menekan toggle manual di navbar, pilihan itu tersimpan dan tidak akan tertimpa preferensi sistem lagi.

### 🤖 AI Assistant Kontekstual & Real-Time
Chat widget yang bisa menjawab pertanyaan seputar Nimzz, proyek GitHub, dan produk yang dijual.

- Data proyek GitHub diambil langsung dari GitHub API dan **diurutkan berdasarkan waktu push terakhir** (bukan jumlah bintang), sehingga pertanyaan seperti *"repo terbaru apa?"* dijawab akurat.
- Cache data GitHub dipersingkat jadi 60 detik — cukup untuk menghindari rate limit API, cukup singkat untuk tetap terasa real-time.
- System prompt secara eksplisit melarang model menjawab dari ingatan/asumsi lama soal nama repo.
- Dibatasi rate limit untuk mencegah penyalahgunaan.

> **Catatan jujur soal AI provider:** assistant ini menggunakan provider pihak ketiga tidak resmi (`unlimitedai.chat`) sebagai backend model, bukan API resmi dari penyedia model manapun. Ini pilihan praktis untuk keperluan portofolio pribadi berbiaya rendah — bukan cocok untuk kebutuhan produksi/komersial serius. Jika ingin hasil yang lebih terjamin, ganti implementasi di `src/lib/unlimitedai.js` dengan API resmi (mis. Anthropic, OpenAI, dsb) yang kamu punya API key-nya sendiri.

### 📦 Project Hub Dinamis
Grid proyek yang diambil real-time dari GitHub, lengkap dengan bahasa, topik, stars, dan forks.

### 🛒 Store
Halaman produk untuk menjual base bot WhatsApp dan jasa sewa bot, dengan modal detail dan integrasi pembelian via Telegram.

### 🔍 SEO & AI Discoverability
Dirancang supaya mudah ditemukan baik oleh search engine tradisional maupun AI assistant modern:

- `robots.txt` yang secara eksplisit mengizinkan crawler AI (GPTBot, ClaudeBot, Google-Extended, PerplexityBot, dll), bukan cuma wildcard.
- `sitemap.xml` dinamis.
- **`llms.txt`** di root domain — file ringkas berformat markdown yang dirancang khusus supaya AI assistant (ChatGPT, Claude, dll) dapat memahami konteks situs secara akurat, mengikuti standar [llmstxt.org](https://llmstxt.org).
- Structured data (JSON-LD) `Person`, `WebSite`, dan `ItemList` untuk halaman proyek — datanya sinkron langsung dengan apa yang ditampilkan di layar, bukan data statis terpisah.

### 🔒 Keamanan
- Rate limiting berbasis Upstash Redis (dengan fallback in-memory untuk lokal) di semua endpoint publik.
- Security headers lengkap: `Content-Security-Policy`, `Strict-Transport-Security`, `X-Frame-Options`, `Permissions-Policy`, dan lainnya.
- Validasi input ketat (panjang pesan, format email, ukuran body request) di endpoint contact & chat.
- Tidak ada raw error yang dibocorkan ke pengguna.
- `.env` dan secret lain tidak pernah ikut ter-commit (lihat `.gitignore`).

---

## Struktur Proyek

```
src/
├── app/
│   ├── about/              # Halaman profil & tech stack
│   ├── contact/            # Form kontak (terhubung ke Telegram)
│   ├── projects/           # Daftar proyek real-time dari GitHub
│   ├── store/               # Halaman produk/jasa
│   ├── api/
│   │   ├── chat/           # Endpoint AI assistant
│   │   └── contact/        # Endpoint pengiriman pesan ke Telegram
│   ├── layout.js           # Root layout, metadata, JSON-LD, theme bootstrap
│   ├── robots.js           # robots.txt dinamis (termasuk aturan AI crawler)
│   ├── sitemap.js          # sitemap.xml dinamis
│   └── globals.css         # Design tokens & tema dark/light
├── components/
│   ├── AIAssistant.js      # Widget chat AI
│   ├── ThemeProvider.js    # Context tema (system-aware + manual override)
│   ├── Navbar.js           # Navigasi + toggle tema
│   ├── ProjectCard.js      # Kartu proyek
│   ├── ProductCard.js/ProductModal.js  # Komponen store
│   ├── GithubActivity.js   # Statistik & kalender kontribusi GitHub
│   └── TechIcons.js        # Ikon teknologi (Font Awesome + SVG fallback)
└── lib/
    ├── github.js           # Fetcher GitHub API (sorting real-time by pushed_at)
    ├── unlimitedai.js      # Klien AI provider
    ├── rateLimit.js        # Rate limiter (Redis + fallback in-memory)
    ├── products.js         # Data produk store
    └── config.js           # Konfigurasi identitas/kontak/situs

public/
└── llms.txt                # Konteks situs untuk AI assistant
```

---

## Tech Stack

- **Framework:** Next.js 16 (App Router, Turbopack)
- **UI:** React 19, Vanilla CSS Modules (CSS Variables untuk theming)
- **Animasi:** Framer Motion, Lenis (smooth scroll)
- **Ikon:** Font Awesome 6 (CDN) + SVG fallback untuk brand yang tidak tersedia di FA
- **AI:** Provider pihak ketiga via `unlimitedai.chat` (lihat catatan di atas)
- **Rate limiting:** Upstash Redis
- **Data proyek:** GitHub REST API (real-time, tanpa database)
- **Analytics:** Vercel Analytics
- **Deployment:** Vercel

---

## Menjalankan Secara Lokal

### Prasyarat
- Node.js 18.18 atau lebih baru
- npm (atau package manager lain yang kompatibel)

### Langkah

```bash
# 1. Clone repository
git clone https://github.com/Nimzz-pemboy/personal-portfolio.git
cd personal-portfolio

# 2. Install dependencies
npm install

# 3. Siapkan environment variables
cp .env.example .env
# lalu isi .env dengan nilai kamu sendiri — lihat bagian "Environment Variables" di bawah

# 4. Jalankan development server
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) di browser.

### Script yang tersedia

| Script | Keterangan |
|---|---|
| `npm run dev` | Development server (Turbopack) |
| `npm run dev:webpack` | Development server (Webpack, jika Turbopack bermasalah) |
| `npm run build` | Build production |
| `npm run build:webpack` | Build production tanpa Turbopack |
| `npm start` | Menjalankan hasil build |
| `npm run lint` | Menjalankan ESLint |

---

## Environment Variables

Salin `.env.example` menjadi `.env` lalu isi:

| Variable | Wajib? | Keterangan |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Ya, untuk form contact | Token bot Telegram dari [@BotFather](https://t.me/BotFather) |
| `TELEGRAM_CHAT_ID` | Ya, untuk form contact | Chat ID tujuan pesan dari form contact |
| `UPSTASH_REDIS_REST_URL` | Opsional (disarankan di production) | URL REST Redis dari [Upstash Console](https://console.upstash.com) |
| `UPSTASH_REDIS_REST_TOKEN` | Opsional (disarankan di production) | Token REST Redis dari Upstash |

> Tanpa kredensial Upstash, rate limiting otomatis fallback ke penghitung in-memory — cukup untuk development lokal, tapi kurang andal di lingkungan serverless (bisa reset saat cold start). Disarankan mengisi Upstash untuk deployment production.

**Penting:** jangan pernah commit file `.env` yang berisi nilai asli. File ini sudah masuk `.gitignore`.

---

## Kustomisasi

Sebagian besar identitas situs (nama, bio, kontak, daftar skill, dsb) terpusat di `src/lib/config.js` — cukup ubah file ini untuk fork/pakai project ini sebagai portofolio sendiri. Data produk store ada di `src/lib/products.js`.

---

## Keamanan

Jika menemukan celah keamanan, mohon **jangan** membuka issue publik. Hubungi langsung lewat kontak yang tersedia di [rpan.biz.id](https://t.me/GustodX) atau Telegram [@GustodX](https://t.me/GustodX).

---

## Kontribusi

Project ini open source di bawah lisensi MIT. Pull request dan issue dipersilakan — terutama untuk perbaikan bug, peningkatan aksesibilitas, atau saran keamanan.

---

## Kontak

- GitHub: [@Nimzz-pemboy](https://github.com/rivan228)
- Telegram: [@Nimzz4](https://t.me/GustodX)
- WhatsApp: [wa.me/6282137487477](https://wa.me/6288989115022)

---

## Lisensi

[MIT](./LICENSE) © Muhamad Bagus Rivan Saputra (Rivan)
