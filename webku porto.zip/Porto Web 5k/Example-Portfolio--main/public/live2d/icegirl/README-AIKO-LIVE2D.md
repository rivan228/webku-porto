# Setup Fitur Aiko Live2D

## File yang ditambah/diubah
```
package.json                          (diubah — nambah pixi.js + pixi-live2d-display)
src/components/ClientProviders.js     (diubah — widget chat lama disembunyiin di /aiko)
src/components/Navbar.js              (diubah — nambah menu "Aiko Live")
src/components/live2d/Live2DStage.js  (baru — komponen render Live2D)
src/app/aiko/page.js                  (baru — halaman utamanya)
src/app/aiko/aiko.module.css          (baru — style halaman)
public/live2d/icegirl/**              (baru — asset model, ~19MB)
```

Cara pasang: copy semua path di atas ke project asli kamu (timpa file yang
sama namanya, tambahin yang baru), lalu:

```bash
npm install
npm run dev
```

Buka `/aiko`.

## Soal model & lisensi
Model "IceGirl" (冰之公主) ini bikinan TianYeLulu, dan izinnya bebas dipakai
buat VTuber activity/video/SNS/dll. Tetep taruh kredit kecil somewhere di
halaman, misal di footer: `Live2D model: @TianYeLulu`.

## Fitur nyanyi
Belum ada file lagunya — tinggal taruh file audio kamu sendiri di:
```
public/audio/aiko-sing.mp3
```
Kalau file belum ada, tombol "Suruh Nyanyi" bakal nunjukin pesan error kecil
di bawahnya, nggak crash.

## Ekspresi & motion yang udah di-wire
20 expression + 3 motion (idle/wave/wink) dari model aslinya udah dipetain ke
`public/live2d/icegirl/IceGirl.model3.json` (file ini di-generate ulang dari
versi originalnya karena nama file expression aslinya pakai karakter Han,
diganti ke slug ASCII biar aman di URL). Manifest lengkapnya ada di
`public/live2d/icegirl/expressions-manifest.json` kalau mau nambah chip lain
di UI selain 10 yang udah dipilih di `page.js`.

## Hal yang perlu dicek pas nyoba di device kamu
Aku susun kodenya berdasarkan dokumentasi resmi pixi.js v6 +
pixi-live2d-display, tapi belum sempat aku `npm install` beneran di sini
(sandbox-ku nggak ada akses internet). Yang paling mungkin perlu disesuaikan:

1. **Import path `pixi-live2d-display/cubism4`** — kalau bundler (Turbopack)
   protes soal subpath ini, coba ganti importnya jadi dari root package
   (`pixi-live2d-display` tanpa `/cubism4`), itu bundlenya lebih besar tapi
   include cubism 2 & 4 sekaligus.
2. Kalau `npm run dev` (Turbopack) rewel soal `window.PIXI` global, coba
   `npm run dev:webpack` — script itu udah ada dari sebelumnya di
   package.json kamu.
3. Texture-nya 4 lembar 8192px (total ~19MB) — lumayan berat buat load
   pertama kali. Kalau kerasa lambat di HP, bisa dikompres ulang texture
   PNG-nya pake tool kayak TinyPNG tanpa perlu ubah model3.json.

Kalau ada error pas dicoba, kirim aja pesan errornya ke aku, kita debug bareng.
